package com.starksyntax.musicplayer.playback

import android.app.Application
import android.content.ComponentName
import android.os.Bundle
import androidx.media3.session.SessionCommand
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.starksyntax.musicplayer.data.KEY_QUEUED
import com.starksyntax.musicplayer.data.MusicRepository
import com.starksyntax.musicplayer.data.Playlist
import com.starksyntax.musicplayer.data.SortOrder
import com.starksyntax.musicplayer.data.TrackDetails
import com.starksyntax.musicplayer.data.UserPrefs
import com.starksyntax.musicplayer.data.buildAlbums
import com.starksyntax.musicplayer.data.buildArtists
import com.starksyntax.musicplayer.data.Song
import com.starksyntax.musicplayer.data.toMediaItem
import com.starksyntax.musicplayer.data.toSongOrNull
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Bridges the UI to [PlaybackService] through a MediaController, and loads
 * the library from MediaStore.
 */
class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MusicRepository(application)
    private val prefs = UserPrefs(application)

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    val albums = _songs.map { buildAlbums(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val artists = _songs.map { buildArtists(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _accent = MutableStateFlow(prefs.loadAccent())
    val accent: StateFlow<Color> = _accent.asStateFlow()

    private val _favoriteIds = MutableStateFlow(prefs.loadFavorites())
    val favoriteIds: StateFlow<Set<Long>> = _favoriteIds.asStateFlow()

    /** Favourites in library order; ids of songs that were deleted from the phone are dropped. */
    val favorites: StateFlow<List<Song>> = combine(_songs, _favoriteIds) { songs, ids ->
        songs.filter { it.id in ids }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _playlists = MutableStateFlow(prefs.loadPlaylists())
    val playlists: StateFlow<List<Playlist>> = _playlists.asStateFlow()

    private val _sort = MutableStateFlow(prefs.loadSort())
    val sort: StateFlow<SortOrder> = _sort.asStateFlow()

    private val _sleepEndsAt = MutableStateFlow(0L)
    /** Wall-clock time (ms) when the sleep timer pauses playback, or 0 when it is off. */
    val sleepEndsAt: StateFlow<Long> = _sleepEndsAt.asStateFlow()

    private val pendingActions = ArrayDeque<(MediaController) -> Unit>()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    /** One-line toasts ("Added to queue"). */
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    private val _libraryLoaded = MutableStateFlow(false)
    val libraryLoaded: StateFlow<Boolean> = _libraryLoaded.asStateFlow()

    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    private val _queue = MutableStateFlow<List<Song>>(emptyList())
    /** Everything in the player's queue, in queue order. */
    val queue: StateFlow<List<Song>> = _queue.asStateFlow()

    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs.asStateFlow()

    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var loadJob: Job? = null
    private var tickerJob: Job? = null

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            syncFrom(player, rebuildQueue = events.contains(Player.EVENT_TIMELINE_CHANGED))
        }
    }

    init {
        connectToService()
    }

    // region Library

    fun refreshLibrary() {
        if (loadJob?.isActive == true) return
        loadJob = viewModelScope.launch {
            val result = try {
                repository.loadSongs()
            } catch (e: SecurityException) {
                null // permission was revoked mid-flight
            }
            if (result != null) _songs.value = result
            _libraryLoaded.value = true
        }
    }

    // endregion

    // region Transport

    /** Runs [block] now, or as soon as the service connects (a tap right at app start is not lost). */
    private fun withController(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else pendingActions.add(block)
    }

    /** Replaces the queue with [queue] and starts playing at [index]. */
    fun play(queue: List<Song>, index: Int) = withController { c ->
        if (index in queue.indices) {
            c.setMediaItems(queue.map { it.toMediaItem() }, index, 0L)
            c.prepare()
            c.play()
        }
    }

    /** PLAY button: whole list in order. SHUFFLE button: whole list in random order. */
    fun playAll(queue: List<Song>, shuffle: Boolean) = withController { c ->
        if (queue.isNotEmpty()) {
            // SHUFFLE reorders the queue itself, so what the queue screen shows is exactly what plays next.
            c.shuffleModeEnabled = false
            val ordered = if (shuffle) queue.shuffled() else queue
            c.setMediaItems(ordered.map { it.toMediaItem() }, 0, 0L)
            c.prepare()
            c.play()
        }
    }

    private fun startSingle(c: MediaController, song: Song) {
        c.setMediaItems(listOf(song.toMediaItem()), 0, 0L)
        c.prepare()
        c.play()
    }

    /** Puts [song] directly after the one that is playing. */
    fun playNext(song: Song) = withController { c ->
        if (c.mediaItemCount == 0) {
            startSingle(c, song)
            _messages.tryEmit("Playing \"${song.title}\"")
        } else {
            insertQueued(c, c.currentMediaItemIndex + 1, song)
            _messages.tryEmit("Playing next: ${song.title}")
        }
    }

    /**
     * Puts [song] after everything the user already queued by hand, but before the rest of the
     * list that was playing. (Appending to the very end would bury it behind thousands of songs.)
     */
    fun addToQueue(song: Song) = withController { c ->
        if (c.mediaItemCount == 0) {
            startSingle(c, song)
            _messages.tryEmit("Playing \"${song.title}\"")
        } else {
            var at = c.currentMediaItemIndex + 1
            while (at < c.mediaItemCount &&
                c.getMediaItemAt(at).mediaMetadata.extras?.getBoolean(KEY_QUEUED) == true
            ) {
                at++
            }
            insertQueued(c, at, song)
            _messages.tryEmit("Added to queue")
        }
    }

    private fun insertQueued(c: MediaController, at: Int, song: Song) {
        val wasEnded = c.playbackState == Player.STATE_ENDED
        c.addMediaItem(at, song.toMediaItem(queued = true))
        if (wasEnded) { // the queue had finished: start with the new song
            c.seekToDefaultPosition(at)
            c.play()
        }
    }

    fun skipToQueueItem(index: Int) {
        val c = controller ?: return
        if (index !in 0 until c.mediaItemCount) return
        c.seekToDefaultPosition(index)
        c.play()
    }

    fun removeFromQueue(index: Int) {
        val c = controller ?: return
        if (index in 0 until c.mediaItemCount && index != c.currentMediaItemIndex) c.removeMediaItem(index)
    }

    fun clearUpNext() {
        val c = controller ?: return
        val from = c.currentMediaItemIndex + 1
        if (from < c.mediaItemCount) {
            c.removeMediaItems(from, c.mediaItemCount)
            _messages.tryEmit("Queue cleared")
        }
    }

    // endregion

    // region Playlists, sort, sleep timer

    private fun updatePlaylists(transform: (List<Playlist>) -> List<Playlist>) {
        val updated = transform(_playlists.value)
        _playlists.value = updated
        prefs.savePlaylists(updated)
    }

    /** Returns the new playlist's id, or null if [name] was blank. */
    fun createPlaylist(name: String, firstSong: Song? = null): Long? {
        val clean = name.trim()
        if (clean.isEmpty()) return null
        val id = System.currentTimeMillis()
        updatePlaylists { it + Playlist(id, clean, listOfNotNull(firstSong?.id)) }
        _messages.tryEmit(if (firstSong != null) "Added to $clean" else "Playlist created")
        return id
    }

    fun renamePlaylist(id: Long, name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        updatePlaylists { list -> list.map { if (it.id == id) it.copy(name = clean) else it } }
    }

    fun deletePlaylist(id: Long) {
        updatePlaylists { list -> list.filterNot { it.id == id } }
        _messages.tryEmit("Playlist deleted")
    }

    fun addToPlaylist(playlistId: Long, song: Song) {
        val playlist = _playlists.value.firstOrNull { it.id == playlistId } ?: return
        if (song.id in playlist.songIds) {
            _messages.tryEmit("Already in ${playlist.name}")
            return
        }
        updatePlaylists { list ->
            list.map { if (it.id == playlistId) it.copy(songIds = it.songIds + song.id) else it }
        }
        _messages.tryEmit("Added to ${playlist.name}")
    }

    fun removeFromPlaylist(playlistId: Long, song: Song) {
        updatePlaylists { list ->
            list.map { if (it.id == playlistId) it.copy(songIds = it.songIds - song.id) else it }
        }
        _messages.tryEmit("Removed from playlist")
    }

    fun setSort(order: SortOrder) {
        _sort.value = order
        prefs.saveSort(order)
    }

    /** 0 turns the timer off. The timer itself runs inside the playback service. */
    fun setSleepTimer(minutes: Int) = withController { c ->
        c.sendCustomCommand(
            SessionCommand(SleepTimer.COMMAND, Bundle.EMPTY),
            Bundle().apply { putInt(SleepTimer.ARG_MINUTES, minutes) },
        )
        _messages.tryEmit(if (minutes > 0) "Music stops in $minutes min" else "Sleep timer off")
    }

    // endregion

    // region Transport

    fun toggleFavorite(song: Song) {
        val current = _favoriteIds.value
        val adding = song.id !in current
        val updated = if (adding) current + song.id else current - song.id
        _favoriteIds.value = updated
        prefs.saveFavorites(updated)
        _messages.tryEmit(if (adding) "Added to favorites" else "Removed from favorites")
    }

    fun setAccent(color: Color) {
        _accent.value = color
        prefs.saveAccent(color)
    }

    suspend fun trackDetails(song: Song): TrackDetails = repository.loadDetails(song)

    fun togglePlayPause() {
        val c = controller ?: return
        if (c.playWhenReady && c.playbackState != Player.STATE_ENDED) {
            c.pause()
        } else {
            if (c.playbackState == Player.STATE_ENDED) c.seekToDefaultPosition(0)
            c.play()
        }
    }

    fun next() {
        controller?.seekToNext()
    }

    fun previous() {
        controller?.seekToPrevious()
    }

    fun seekToFraction(fraction: Float) {
        val c = controller ?: return
        val duration = _state.value.durationMs
        if (duration <= 0L) return
        val target = (duration * fraction.coerceIn(0f, 1f)).toLong()
        c.seekTo(target)
        _positionMs.value = target
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    // endregion

    // region Service connection

    private fun connectToService() {
        val context = getApplication<Application>()
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token)
            .setListener(object : MediaController.Listener {
                override fun onExtrasChanged(controller: MediaController, extras: Bundle) {
                    _sleepEndsAt.value = extras.getLong(SleepTimer.EXTRA_ENDS_AT, 0L)
                }
            })
            .buildAsync()
        controllerFuture = future
        future.addListener(
            {
                val connected = try {
                    future.get()
                } catch (e: Exception) {
                    null // cancelled (ViewModel cleared) or service failed to start
                }
                if (connected != null) {
                    controller = connected
                    connected.addListener(playerListener)
                    syncFrom(connected, rebuildQueue = true)
                    _sleepEndsAt.value = connected.sessionExtras.getLong(SleepTimer.EXTRA_ENDS_AT, 0L)
                    while (pendingActions.isNotEmpty()) pendingActions.removeFirst()(connected)
                }
            },
            ContextCompat.getMainExecutor(context),
        )
    }

    private fun syncFrom(player: Player, rebuildQueue: Boolean) {
        if (rebuildQueue) {
            _queue.value = (0 until player.mediaItemCount).mapNotNull { player.getMediaItemAt(it).toSongOrNull() }
        }
        val song = player.currentMediaItem?.toSongOrNull()
        val reportedDuration = player.duration
        val duration = if (reportedDuration != C.TIME_UNSET && reportedDuration > 0L) {
            reportedDuration
        } else {
            song?.durationMs ?: 0L
        }
        val playbackState = player.playbackState
        val playing = player.playWhenReady &&
            playbackState != Player.STATE_ENDED &&
            playbackState != Player.STATE_IDLE

        _state.value = PlayerUiState(
            currentSong = song,
            isPlaying = playing,
            durationMs = duration,
            shuffle = player.shuffleModeEnabled,
            repeatMode = player.repeatMode,
            queueIndex = player.currentMediaItemIndex,
        )
        _positionMs.value = player.currentPosition.coerceAtLeast(0L)
        updateTicker(playing)
    }

    private fun updateTicker(playing: Boolean) {
        if (!playing) {
            tickerJob?.cancel()
            tickerJob = null
            return
        }
        if (tickerJob?.isActive == true) return
        tickerJob = viewModelScope.launch {
            while (isActive) {
                controller?.let { _positionMs.value = it.currentPosition.coerceAtLeast(0L) }
                delay(300)
            }
        }
    }

    override fun onCleared() {
        tickerJob?.cancel()
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onCleared()
    }

    // endregion
}
