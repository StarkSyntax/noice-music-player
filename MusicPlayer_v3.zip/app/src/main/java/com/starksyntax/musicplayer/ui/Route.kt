package com.starksyntax.musicplayer.ui

/** Screens that sit on top of the home tabs. */
sealed interface Route {
    data object Settings : Route
    data class Album(val key: String) : Route
    data class Artist(val name: String) : Route
    data class Playlist(val id: Long) : Route
}
