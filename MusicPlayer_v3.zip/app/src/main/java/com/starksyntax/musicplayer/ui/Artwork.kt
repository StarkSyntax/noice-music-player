package com.starksyntax.musicplayer.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.starksyntax.musicplayer.data.Song
import com.starksyntax.musicplayer.ui.doodle.DoodleIcon
import com.starksyntax.musicplayer.ui.doodle.Glyph
import com.starksyntax.musicplayer.ui.doodle.doodleFrame
import com.starksyntax.musicplayer.ui.theme.Chalk
import com.starksyntax.musicplayer.ui.theme.LocalAccent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ArtworkLoader {

    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
    }
    private val missing = HashSet<String>() // songs known to have no art

    private fun keyOf(song: Song, sizePx: Int) = "${song.id}:$sizePx"

    fun peek(song: Song, sizePx: Int): Bitmap? = cache.get(keyOf(song, sizePx))

    fun isMissing(song: Song, sizePx: Int): Boolean = synchronized(missing) { keyOf(song, sizePx) in missing }

    suspend fun load(context: Context, song: Song, sizePx: Int): Bitmap? =
        withContext(Dispatchers.IO) {
            val key = keyOf(song, sizePx)
            cache.get(key)?.let { return@withContext it }
            val bitmap = decode(context, song, sizePx)
            if (bitmap != null) cache.put(key, bitmap) else synchronized(missing) { missing.add(key) }
            bitmap
        }

    private fun decode(context: Context, song: Song, sizePx: Int): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            context.contentResolver.loadThumbnail(song.uri, Size(sizePx, sizePx), null)
        } else {
            decodeLegacy(context, song, sizePx)
        }
    } catch (e: Exception) {
        null // no embedded or folder art for this song
    }

    private fun decodeLegacy(context: Context, song: Song, sizePx: Int): Bitmap? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(song.albumArtUri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (bounds.outWidth / (sample * 2) >= sizePx && bounds.outHeight / (sample * 2) >= sizePx) {
            sample *= 2
        }
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return resolver.openInputStream(song.albumArtUri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }
}

@Composable
private fun rememberBitmap(song: Song?, sizePx: Int): Bitmap? {
    val appContext = LocalContext.current.applicationContext
    val state = produceState(
        initialValue = song?.let { ArtworkLoader.peek(it, sizePx) },
        song?.id, sizePx,
    ) {
        value = song?.let { ArtworkLoader.peek(it, sizePx) } // never show the previous song's art
        if (song != null && value == null && !ArtworkLoader.isMissing(song, sizePx)) {
            value = ArtworkLoader.load(appContext, song, sizePx)
        }
    }
    return state.value
}

/**
 * Album art inside a hand-drawn frame. Without art: a black tile with an accent doodle note.
 * Pass any song of the album/artist; [radius] big enough makes it a circle.
 */
@Composable
fun ArtTile(
    song: Song?,
    modifier: Modifier = Modifier,
    radius: Dp = 14.dp,
    sizePx: Int = 160,
    line: Color = Chalk,
    seed: Int = 1,
) {
    val bitmap = rememberBitmap(song, sizePx)
    Box(
        modifier.doodleFrame(line = line, ink = line, radius = radius, stroke = 1.8.dp, sketch = false, seed = seed),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .padding(5.dp)
                .clip(RoundedCornerShape(radius)),
            contentAlignment = Alignment.Center,
        ) {
            if (bitmap != null) {
                val image = remember(bitmap) { bitmap.asImageBitmap() }
                Image(
                    bitmap = image,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                DoodleIcon(
                    glyph = Glyph.Note,
                    tint = LocalAccent.current,
                    size = Dp.Unspecified,
                    modifier = Modifier.fillMaxSize(0.5f),
                    seed = seed,
                )
            }
        }
    }
}
