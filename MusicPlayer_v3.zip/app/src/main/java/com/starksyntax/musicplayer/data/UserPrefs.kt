package com.starksyntax.musicplayer.data

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.starksyntax.musicplayer.ui.theme.Volt
import org.json.JSONArray
import org.json.JSONObject

/** Tiny SharedPreferences wrapper: accent colour and favourites survive restarts. */
class UserPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("noice_prefs", Context.MODE_PRIVATE)

    fun loadAccent(): Color =
        if (prefs.contains(KEY_ACCENT)) Color(prefs.getInt(KEY_ACCENT, Volt.toArgb())) else Volt

    fun saveAccent(color: Color) {
        prefs.edit().putInt(KEY_ACCENT, color.toArgb()).apply()
    }

    fun loadFavorites(): Set<Long> =
        prefs.getStringSet(KEY_FAVORITES, emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()

    fun saveFavorites(ids: Set<Long>) {
        prefs.edit().putStringSet(KEY_FAVORITES, ids.map { it.toString() }.toSet()).apply()
    }

    fun loadPlaylists(): List<Playlist> {
        val raw = prefs.getString(KEY_PLAYLISTS, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val o = array.getJSONObject(i)
                val ids = o.getJSONArray("songs")
                Playlist(o.getLong("id"), o.getString("name"), (0 until ids.length()).map { ids.getLong(it) })
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun savePlaylists(list: List<Playlist>) {
        val array = JSONArray()
        list.forEach { p ->
            array.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("songs", JSONArray(p.songIds)),
            )
        }
        prefs.edit().putString(KEY_PLAYLISTS, array.toString()).apply()
    }

    fun loadSort(): SortOrder =
        SortOrder.values().firstOrNull { it.name == prefs.getString(KEY_SORT, null) } ?: SortOrder.Title

    fun saveSort(order: SortOrder) {
        prefs.edit().putString(KEY_SORT, order.name).apply()
    }

    private companion object {
        const val KEY_PLAYLISTS = "playlists"
        const val KEY_SORT = "sort"
        const val KEY_ACCENT = "accent"
        const val KEY_FAVORITES = "favorites"
    }
}
