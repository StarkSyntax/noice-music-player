package com.starksyntax.musicplayer.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.starksyntax.musicplayer.data.Song
import com.starksyntax.musicplayer.ui.doodle.DoodleIconButton
import com.starksyntax.musicplayer.ui.doodle.Glyph
import com.starksyntax.musicplayer.ui.doodle.opaqueOverlay
import com.starksyntax.musicplayer.ui.theme.Chalk
import com.starksyntax.musicplayer.ui.theme.Fog

/** One album or one artist: cover, name, PLAY / SHUFFLE and the songs. */
@Composable
fun DetailScreen(
    title: String,
    subtitle: String,
    artSong: Song?,
    roundArt: Boolean,
    songs: List<Song>,
    env: SongEnv,
    bottomInset: Dp,
    onBack: () -> Unit,
    emptyText: String = "No songs here.",
    trailing: (@Composable () -> Unit)? = null,
) {
    Column(Modifier.opaqueOverlay().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            DoodleIconButton(Glyph.Back, "Back", onBack)
            Spacer(Modifier.weight(1f))
            trailing?.invoke()
        }
        SongList(
            songs = songs,
            env = env,
            bottomInset = bottomInset,
            emptyText = emptyText,
            header = {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    ArtTile(
                        song = artSong,
                        modifier = Modifier.size(112.dp),
                        radius = if (roundArt) 112.dp else 22.dp,
                        sizePx = 360,
                        seed = 6,
                    )
                    Spacer(Modifier.width(18.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            title,
                            style = MaterialTheme.typography.headlineMedium,
                            color = Chalk,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(subtitle, style = MaterialTheme.typography.labelSmall, color = Fog)
                    }
                }
            },
        )
    }
}
