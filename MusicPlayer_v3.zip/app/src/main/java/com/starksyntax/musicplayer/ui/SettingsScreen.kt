package com.starksyntax.musicplayer.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.starksyntax.musicplayer.R
import com.starksyntax.musicplayer.ui.doodle.DoodleButton
import com.starksyntax.musicplayer.ui.doodle.DoodleCircleButton
import com.starksyntax.musicplayer.ui.doodle.DoodleIcon
import com.starksyntax.musicplayer.ui.doodle.DoodleIconButton
import com.starksyntax.musicplayer.ui.doodle.DoodleSlider
import com.starksyntax.musicplayer.ui.doodle.EqualizerBars
import com.starksyntax.musicplayer.ui.doodle.Glyph
import com.starksyntax.musicplayer.ui.doodle.bouncyClickable
import com.starksyntax.musicplayer.ui.doodle.doodleFrame
import com.starksyntax.musicplayer.ui.doodle.doodleUnderline
import com.starksyntax.musicplayer.ui.doodle.opaqueOverlay
import com.starksyntax.musicplayer.ui.theme.AccentPreset
import com.starksyntax.musicplayer.ui.theme.AccentPresets
import com.starksyntax.musicplayer.ui.theme.SoftPresets
import com.starksyntax.musicplayer.ui.theme.Chalk
import com.starksyntax.musicplayer.ui.theme.Fog
import com.starksyntax.musicplayer.ui.theme.LocalAccent
import com.starksyntax.musicplayer.ui.theme.LocalAccentInk
import com.starksyntax.musicplayer.ui.theme.readableInk

private val HueTrack = (0..12).map { Color.hsv(it * 30f, 0.85f, 1f) }

private fun hsvOf(color: Color): FloatArray {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(android.graphics.Color.rgb(
        (color.red * 255f + 0.5f).toInt(),
        (color.green * 255f + 0.5f).toInt(),
        (color.blue * 255f + 0.5f).toInt(),
    ), hsv)
    return hsv
}

private const val MIN_SAT = 0.15f
private const val MAX_SAT = 0.95f

@Composable
fun SettingsScreen(
    accent: Color,
    onAccentChange: (Color) -> Unit,
    onBack: () -> Unit,
) {
    val ink = LocalAccentInk.current
    var dragHue by remember { mutableStateOf<Float?>(null) }
    var dragSat by remember { mutableStateOf<Float?>(null) }
    val hsv = hsvOf(accent)
    val hue = dragHue ?: (hsv[0] / 360f)
    val sat = dragSat ?: ((hsv[1] - MIN_SAT) / (MAX_SAT - MIN_SAT)).coerceIn(0f, 1f)

    Column(Modifier.opaqueOverlay().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.padding(start = 4.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            DoodleIconButton(Glyph.Back, "Back", onBack)
            Text("SETTINGS", style = MaterialTheme.typography.labelMedium, color = Fog)
        }

        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        ) {
            Spacer(Modifier.height(8.dp))
            Box(Modifier.doodleUnderline(accent, stroke = 3.dp, amplitude = 2.dp, seed = 4).padding(bottom = 10.dp)) {
                Text("Accent colour", style = MaterialTheme.typography.headlineMedium, color = Chalk)
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "Colours every button, slider and highlight in the app.",
                style = MaterialTheme.typography.bodyMedium,
                color = Fog,
            )
            Spacer(Modifier.height(20.dp))

            SwatchGrid("VIVID", AccentPresets, accent, 0) { dragHue = null; dragSat = null; onAccentChange(it) }
            Spacer(Modifier.height(8.dp))
            SwatchGrid("SOFT", SoftPresets, accent, 8) { dragHue = null; dragSat = null; onAccentChange(it) }

            Spacer(Modifier.height(6.dp))
            Text("OR MIX YOUR OWN", style = MaterialTheme.typography.labelMedium, color = Fog)
            Text("Colour", style = MaterialTheme.typography.labelSmall, color = Fog)
            DoodleSlider(
                fraction = hue,
                onChange = {
                    dragHue = it
                    onAccentChange(Color.hsv(it * 360f, MIN_SAT + sat * (MAX_SAT - MIN_SAT), 1f))
                },
                onChangeFinished = { dragHue = null },
                trackColors = HueTrack,
            )
            Text("Softness", style = MaterialTheme.typography.labelSmall, color = Fog)
            DoodleSlider(
                fraction = sat,
                onChange = {
                    dragSat = it
                    onAccentChange(Color.hsv(hue * 360f, MIN_SAT + it * (MAX_SAT - MIN_SAT), 1f))
                },
                onChangeFinished = { dragSat = null },
                trackColors = listOf(
                    Color.hsv(hue * 360f, MIN_SAT, 1f),
                    Color.hsv(hue * 360f, MAX_SAT, 1f),
                ),
            )

            Spacer(Modifier.height(18.dp))
            Text("PREVIEW", style = MaterialTheme.typography.labelMedium, color = Fog)
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .doodleFrame(line = Chalk, ink = Chalk, radius = 22.dp, stroke = 1.8.dp, seed = 14)
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                DoodleCircleButton(Glyph.Play, "Preview play button", onClick = {}, size = 56.dp)
                DoodleButton(onClick = {}, filled = true, seed = 3) {
                    Text("PLAY", style = MaterialTheme.typography.labelMedium, color = ink)
                }
                DoodleIcon(Glyph.Heart, tint = accent, size = 28.dp, filled = true)
                EqualizerBars(playing = true, color = accent, modifier = Modifier.size(28.dp))
            }

            Spacer(Modifier.height(36.dp))
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(R.drawable.noice_logo),
                    contentDescription = "NOICE logo",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth(0.7f),
                )
                Spacer(Modifier.height(20.dp))
                Column(
                    Modifier
                        .fillMaxWidth()
                        .doodleFrame(line = Chalk, ink = Chalk, radius = 22.dp, stroke = 1.8.dp, hatch = true, seed = 17)
                        .padding(horizontal = 28.dp, vertical = 22.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    listOf("Native", "Offline", "Interface", "for Curated", "Entertainment").forEach { phrase ->
                        // A leading lowercase "for" is a small connector; the capital letter is the NOICE letter.
                        val connector = if (phrase.startsWith("for ")) "for " else ""
                        val word = phrase.removePrefix(connector)
                        Row(verticalAlignment = Alignment.Bottom) {
                            if (connector.isNotEmpty()) {
                                Text(
                                    connector.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Fog,
                                    modifier = Modifier.padding(bottom = 4.dp, end = 4.dp),
                                )
                            }
                            Text(
                                word.first().toString(),
                                style = MaterialTheme.typography.headlineMedium,
                                color = accent,
                            )
                            Text(
                                word.drop(1).uppercase(),
                                style = MaterialTheme.typography.titleMedium,
                                color = Chalk,
                                modifier = Modifier.padding(bottom = 3.dp),
                            )
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("v0.4 · plays only what is on your phone", style = MaterialTheme.typography.labelSmall, color = Fog)
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SwatchGrid(
    title: String,
    presets: List<AccentPreset>,
    accent: Color,
    seedBase: Int,
    onPick: (Color) -> Unit,
) {
    Text(title, style = MaterialTheme.typography.labelMedium, color = Fog)
    Spacer(Modifier.height(10.dp))
    presets.chunked(4).forEachIndexed { rowIndex, row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            row.forEachIndexed { i, preset ->
                val selected = preset.color == accent
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier
                            .size(64.dp)
                            .bouncyClickable { onPick(preset.color) }
                            .doodleFrame(
                                line = if (selected) Chalk else preset.color,
                                fill = preset.color,
                                ink = preset.color.readableInk(),
                                radius = 64.dp,
                                stroke = if (selected) 2.8.dp else 2.dp,
                                hatch = true,
                                seed = seedBase + rowIndex * 4 + i + 3,
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (selected) {
                            DoodleIcon(Glyph.Check, tint = preset.color.readableInk(), size = 28.dp, weight = 2.4f)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        preset.name.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) accent else Fog,
                    )
                }
            }
        }
        Spacer(Modifier.height(14.dp))
    }
}
