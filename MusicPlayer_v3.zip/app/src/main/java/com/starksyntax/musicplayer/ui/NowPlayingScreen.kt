package com.starksyntax.musicplayer.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.activity.compose.BackHandler
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import com.starksyntax.musicplayer.ui.doodle.DoodleIcon
import com.starksyntax.musicplayer.ui.doodle.EqualizerBars
import com.starksyntax.musicplayer.ui.doodle.bouncyClickable
import com.starksyntax.musicplayer.ui.doodle.doodleUnderline
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import com.starksyntax.musicplayer.data.Song
import com.starksyntax.musicplayer.playback.PlayerUiState
import com.starksyntax.musicplayer.ui.doodle.DoodleCircleButton
import com.starksyntax.musicplayer.ui.doodle.DoodleIconButton
import com.starksyntax.musicplayer.ui.doodle.DoodleSlider
import com.starksyntax.musicplayer.ui.doodle.Glyph
import com.starksyntax.musicplayer.ui.doodle.opaqueOverlay
import com.starksyntax.musicplayer.ui.theme.Chalk
import com.starksyntax.musicplayer.ui.theme.Fog
import com.starksyntax.musicplayer.ui.theme.LocalAccent

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NowPlayingScreen(
    song: Song,
    state: PlayerUiState,
    queue: List<Song>,
    positionMs: State<Long>,
    isFavorite: Boolean,
    onClose: () -> Unit,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Float) -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleFavorite: () -> Unit,
    onSkipTo: (Int) -> Unit,
    onRemoveFromQueue: (Int) -> Unit,
    onClearUpNext: () -> Unit,
    sleepActive: Boolean,
    onOpenSleep: () -> Unit,
) {
    val accent = LocalAccent.current
    var showQueue by remember { mutableStateOf(false) }
    BackHandler(enabled = showQueue) { showQueue = false }

    // The cover "breathes": full size while playing, a little smaller when paused.
    val artScale by animateFloatAsState(
        targetValue = if (state.isPlaying) 1f else 0.93f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "artScale",
    )
    val swipeNext by rememberUpdatedState(onNext)
    val swipePrevious by rememberUpdatedState(onPrevious)

    if (showQueue) {
        QueuePanel(
            queue = queue,
            currentIndex = state.queueIndex,
            isPlaying = state.isPlaying,
            shuffleOn = state.shuffle,
            onSkipTo = onSkipTo,
            onRemove = onRemoveFromQueue,
            onClear = onClearUpNext,
            onClose = { showQueue = false },
        )
        return
    }

    Column(
        Modifier
            .opaqueOverlay()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            DoodleIconButton(Glyph.ChevronDown, "Close", onClose, iconSize = 28.dp)
            Spacer(Modifier.weight(1f))
            Text("NOW PLAYING", style = MaterialTheme.typography.labelMedium, color = Fog)
            Spacer(Modifier.weight(1f))
            DoodleIconButton(Glyph.Queue, "Queue", { showQueue = true })
        }

        Spacer(Modifier.height(16.dp))

        // Cover. Swipe left / right to change song.
        ArtTile(
            song = song,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .graphicsLayer {
                    scaleX = artScale
                    scaleY = artScale
                }
                .pointerInput(Unit) {
                    var total = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = {
                            if (total < -120f) swipeNext() else if (total > 120f) swipePrevious()
                        },
                        onHorizontalDrag = { change, amount ->
                            change.consume()
                            total += amount
                        },
                    )
                },
            radius = 30.dp,
            sizePx = 720,
            line = accent,
            seed = 31,
        )

        Spacer(Modifier.height(26.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = song.title,
                    style = MaterialTheme.typography.headlineMedium,
                    color = Chalk,
                    maxLines = 1,
                    modifier = Modifier.basicMarquee(),
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = song.artist,
                    style = MaterialTheme.typography.bodyLarge,
                    color = Fog,
                    maxLines = 1,
                    modifier = Modifier.basicMarquee(),
                )
            }
            DoodleIconButton(
                glyph = Glyph.Heart,
                description = if (isFavorite) "Remove from favorites" else "Add to favorites",
                onClick = onToggleFavorite,
                tint = if (isFavorite) accent else Chalk,
                iconSize = 30.dp,
                filled = isFavorite,
                hitSize = 52.dp,
            )
        }

        Spacer(Modifier.height(10.dp))
        SeekBar(positionMs = positionMs, durationMs = state.durationMs, onSeek = onSeek)

        Spacer(Modifier.weight(1f))

        // Peek at what is coming; tap to open the full queue.
        val upNext = queue.getOrNull(state.queueIndex + 1)
        Row(
            Modifier
                .fillMaxWidth()
                .bouncyClickable(pressedScale = 0.97f) { showQueue = true }
                .padding(vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            DoodleIcon(Glyph.Queue, tint = accent, size = 20.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (state.shuffle) "UP NEXT · SHUFFLE IS ON" else "UP NEXT",
                    style = MaterialTheme.typography.labelSmall,
                    color = Fog,
                )
                Text(
                    text = when {
                        state.shuffle -> "Tap to see the queue"
                        upNext != null -> "${upNext.title} · ${upNext.artist}"
                        else -> "End of the queue"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = Chalk,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            DoodleIconButton(
                glyph = Glyph.Timer,
                description = "Sleep timer",
                onClick = onOpenSleep,
                tint = if (sleepActive) accent else Fog,
            )
        }
        Spacer(Modifier.height(8.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            DoodleIconButton(
                glyph = Glyph.Shuffle,
                description = "Shuffle",
                onClick = onToggleShuffle,
                tint = if (state.shuffle) accent else Fog,
            )
            DoodleIconButton(Glyph.Previous, "Previous", onPrevious, iconSize = 30.dp, hitSize = 56.dp)
            DoodleCircleButton(
                glyph = if (state.isPlaying) Glyph.Pause else Glyph.Play,
                description = if (state.isPlaying) "Pause" else "Play",
                onClick = onTogglePlay,
            )
            DoodleIconButton(Glyph.Next, "Next", onNext, iconSize = 30.dp, hitSize = 56.dp)
            DoodleIconButton(
                glyph = if (state.repeatMode == Player.REPEAT_MODE_ONE) Glyph.RepeatOne else Glyph.Repeat,
                description = "Repeat",
                onClick = onCycleRepeat,
                tint = if (state.repeatMode == Player.REPEAT_MODE_OFF) Fog else accent,
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SeekBar(positionMs: State<Long>, durationMs: Long, onSeek: (Float) -> Unit) {
    var dragFraction by remember { mutableStateOf<Float?>(null) }
    val position = positionMs.value
    val fraction = dragFraction
        ?: if (durationMs > 0L) (position.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    val shownPosition = dragFraction?.let { (it * durationMs).toLong() } ?: position

    Column {
        DoodleSlider(
            fraction = fraction,
            onChange = { dragFraction = it },
            onChangeFinished = {
                onSeek(it)
                dragFraction = null
            },
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp)) {
            Text(formatDuration(shownPosition), style = MaterialTheme.typography.labelSmall, color = Fog)
            Spacer(Modifier.weight(1f))
            Text(formatDuration(durationMs), style = MaterialTheme.typography.labelSmall, color = Fog)
        }
    }
}

@Composable
private fun QueuePanel(
    queue: List<Song>,
    currentIndex: Int,
    isPlaying: Boolean,
    shuffleOn: Boolean,
    onSkipTo: (Int) -> Unit,
    onRemove: (Int) -> Unit,
    onClear: () -> Unit,
    onClose: () -> Unit,
) {
    val accent = LocalAccent.current
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = (currentIndex - 1).coerceAtLeast(0))
    Column(Modifier.opaqueOverlay().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            DoodleIconButton(Glyph.ChevronDown, "Back to player", onClose, iconSize = 28.dp)
            Spacer(Modifier.weight(1f))
            Text("QUEUE · ${queue.size}", style = MaterialTheme.typography.labelMedium, color = Fog)
            Spacer(Modifier.weight(1f))
            if (currentIndex + 1 < queue.size) {
                DoodleIconButton(Glyph.Trash, "Clear up next", onClear, tint = Fog)
            } else {
                Spacer(Modifier.size(48.dp))
            }
        }
        if (shuffleOn) {
            Text(
                "Shuffle is on, so the next song may not be the one below it.",
                style = MaterialTheme.typography.bodyMedium,
                color = Fog,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
            )
        }
        LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = 24.dp)) {
            itemsIndexed(queue, key = { index, _ -> index }) { index, song ->
                Column {
                    if (index == currentIndex) {
                        Text("NOW PLAYING", style = MaterialTheme.typography.labelSmall, color = accent,
                            modifier = Modifier.padding(start = 20.dp, top = 14.dp, bottom = 4.dp))
                    } else if (index == currentIndex + 1) {
                        Text("UP NEXT", style = MaterialTheme.typography.labelSmall, color = Fog,
                            modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 4.dp))
                    }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .bouncyClickable(pressedScale = 0.97f) { onSkipTo(index) }
                            .doodleUnderline(Color(0x1FFFFFFF), stroke = 1.dp, amplitude = 1.dp, seed = index % 50)
                            .padding(horizontal = 16.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) {
                            ArtTile(song, Modifier.fillMaxSize(), radius = 12.dp, sizePx = 160, seed = index % 13)
                            if (index == currentIndex) {
                                Box(
                                    Modifier.fillMaxSize().padding(5.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xAA000000)),
                                    contentAlignment = Alignment.Center,
                                ) { EqualizerBars(playing = isPlaying, color = accent, modifier = Modifier.size(18.dp)) }
                            }
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(song.title, style = MaterialTheme.typography.titleMedium,
                                color = if (index == currentIndex) accent else Chalk,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(song.artist, style = MaterialTheme.typography.bodyMedium, color = Fog,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text(formatDuration(song.durationMs), style = MaterialTheme.typography.labelSmall, color = Fog)
                        if (index != currentIndex) {
                            DoodleIconButton(
                                Glyph.Close, "Remove from queue", { onRemove(index) },
                                tint = Fog, iconSize = 18.dp, hitSize = 40.dp,
                            )
                        } else {
                            Spacer(Modifier.width(40.dp))
                        }
                    }
                }
            }
        }
    }
}
