package com.starksyntax.musicplayer.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color

// Deep black everywhere. Chalk is the "pen" colour for outlines and text.
val Ink = Color(0xFF000000)
val Chalk = Color(0xFFF4F4EE)
val Fog = Color(0xFF9A9AA3)

/** Default accent: radium. */
val Volt = Color(0xFFC6F432)

@Immutable
data class AccentPreset(val name: String, val color: Color)

val AccentPresets = listOf(
    AccentPreset("Radium", Volt),
    AccentPreset("Cyan", Color(0xFF22E5FF)),
    AccentPreset("Pink", Color(0xFFFF3D9A)),
    AccentPreset("Orange", Color(0xFFFF8A1F)),
    AccentPreset("Violet", Color(0xFFB06BFF)),
    AccentPreset("Yellow", Color(0xFFFFE53B)),
    AccentPreset("Red", Color(0xFFFF4D4D)),
    AccentPreset("Mint", Color(0xFF35F0A8)),
)

/** Calmer colours for people who find the vivid set too loud. */
val SoftPresets = listOf(
    AccentPreset("Bone", Color(0xFFE8E4D9)),
    AccentPreset("Sage", Color(0xFF9DB89A)),
    AccentPreset("Sky", Color(0xFF8FB4D9)),
    AccentPreset("Rose", Color(0xFFD9A0A8)),
    AccentPreset("Sand", Color(0xFFD6B98C)),
    AccentPreset("Lilac", Color(0xFFB5A6D9)),
    AccentPreset("Slate", Color(0xFF9AA5B1)),
    AccentPreset("Peach", Color(0xFFE8B49A)),
)
