package com.starksyntax.musicplayer.data

import android.content.ContentUris
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.compose.runtime.Immutable
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

/**
 * A song on the device. Everything here is derived from MediaStore columns;
 * the playable [uri] is computed from [id] so a Song can be rebuilt from a
 * MediaItem that came back from the playback service.
 */
@Immutable
data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val track: Int = 0,
    /** Seconds since epoch when the file was added to the phone. */
    val added: Long = 0L,
) {
    val uri: Uri
        get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)

    /** Legacy album-art URI. Used for pre-Android 10 decoding and for notification art. */
    val albumArtUri: Uri
        get() = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
}

/** Marks items the user put in the queue by hand ("Play next" / "Add to queue"). */
const val KEY_QUEUED = "queued"
private const val KEY_ALBUM_ID = "albumId"
private const val KEY_DURATION = "durationMs"

fun Song.toMediaItem(queued: Boolean = false): MediaItem =
    MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(albumArtUri)
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .setExtras(
                    Bundle().apply {
                        putLong(KEY_ALBUM_ID, albumId)
                        putLong(KEY_DURATION, durationMs)
                        putBoolean(KEY_QUEUED, queued)
                    },
                )
                .build(),
        )
        .build()

fun MediaItem.toSongOrNull(): Song? {
    val songId = mediaId.toLongOrNull() ?: return null
    val meta = mediaMetadata
    return Song(
        id = songId,
        title = meta.title?.toString().orEmpty().ifBlank { "Unknown title" },
        artist = meta.artist?.toString().orEmpty().ifBlank { "Unknown artist" },
        album = meta.albumTitle?.toString().orEmpty(),
        albumId = meta.extras?.getLong(KEY_ALBUM_ID) ?: 0L,
        durationMs = meta.extras?.getLong(KEY_DURATION) ?: 0L,
    )
}
