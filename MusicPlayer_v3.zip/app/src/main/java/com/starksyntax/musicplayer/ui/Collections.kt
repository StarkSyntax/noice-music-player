package com.starksyntax.musicplayer.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.starksyntax.musicplayer.data.Album
import com.starksyntax.musicplayer.data.Artist
import com.starksyntax.musicplayer.data.Playlist
import com.starksyntax.musicplayer.data.Song
import com.starksyntax.musicplayer.ui.doodle.DoodleButton
import com.starksyntax.musicplayer.ui.doodle.DoodleIcon
import com.starksyntax.musicplayer.ui.doodle.Glyph
import com.starksyntax.musicplayer.ui.doodle.bouncyClickable
import com.starksyntax.musicplayer.ui.doodle.doodleUnderline
import com.starksyntax.musicplayer.ui.theme.Chalk
import com.starksyntax.musicplayer.ui.theme.Fog

@Composable
fun AlbumsTab(
    albums: List<Album>,
    loaded: Boolean,
    bottomInset: Dp,
    onOpen: (Album) -> Unit,
) {
    if (albums.isEmpty()) {
        EmptyNote(if (loaded) "No albums yet." else "Looking for songs…", Modifier.padding(top = 56.dp))
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = bottomInset),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp),
    ) {
        gridItemsIndexed(albums, key = { _, album -> album.key }) { index, album ->
            Column(Modifier.bouncyClickable(pressedScale = 0.95f) { onOpen(album) }) {
                ArtTile(
                    song = album.songs.first(),
                    modifier = Modifier.fillMaxWidth().aspectRatio(1f),
                    radius = 22.dp,
                    sizePx = 360,
                    seed = index + 2,
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    album.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = Chalk,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "${album.artist} · ${album.songs.size}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Fog,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
fun ArtistsTab(
    artists: List<Artist>,
    loaded: Boolean,
    bottomInset: Dp,
    onOpen: (Artist) -> Unit,
) {
    if (artists.isEmpty()) {
        EmptyNote(if (loaded) "No artists yet." else "Looking for songs…", Modifier.padding(top = 56.dp))
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 6.dp, bottom = bottomInset)) {
        itemsIndexed(artists, key = { _, artist -> artist.name.lowercase() }) { index, artist ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .bouncyClickable(pressedScale = 0.97f) { onOpen(artist) }
                    .doodleUnderline(Color(0x1FFFFFFF), stroke = 1.dp, amplitude = 1.dp, seed = index + 1)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ArtTile(
                    song = artist.songs.first(),
                    modifier = Modifier.size(56.dp),
                    radius = 56.dp, // fully round
                    sizePx = 160,
                    seed = index + 4,
                )
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        artist.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = Chalk,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        "${trackCountLabel(artist.songs.size)} · ${albumCountLabel(artist.albumCount)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Fog,
                    )
                }
            }
        }
    }
}

@Composable
fun PlaylistsTab(
    playlists: List<Playlist>,
    songsById: Map<Long, Song>,
    bottomInset: Dp,
    onOpen: (Playlist) -> Unit,
    onCreate: () -> Unit,
) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomInset)) {
        item(key = "new") {
            DoodleButton(
                onClick = onCreate,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                filled = false,
                seed = 21,
            ) {
                DoodleIcon(Glyph.Plus, tint = Chalk, size = 18.dp)
                Spacer(Modifier.width(8.dp))
                Text("NEW PLAYLIST", style = MaterialTheme.typography.labelMedium, color = Chalk)
            }
        }
        if (playlists.isEmpty()) {
            item(key = "empty") {
                EmptyNote(
                    "No playlists yet.\nMake one here, then add songs from the ⋮ menu.",
                    Modifier.padding(top = 40.dp),
                )
            }
        }
        itemsIndexed(playlists, key = { _, playlist -> playlist.id }) { index, playlist ->
            val count = playlist.songIds.count { it in songsById }
            Row(
                Modifier
                    .fillMaxWidth()
                    .bouncyClickable(pressedScale = 0.97f) { onOpen(playlist) }
                    .doodleUnderline(Color(0x1FFFFFFF), stroke = 1.dp, amplitude = 1.dp, seed = index + 1)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ArtTile(
                    song = playlist.songIds.firstNotNullOfOrNull { songsById[it] },
                    modifier = Modifier.size(56.dp),
                    radius = 14.dp,
                    sizePx = 160,
                    seed = index + 7,
                )
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        playlist.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = Chalk,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(trackCountLabel(count), style = MaterialTheme.typography.labelSmall, color = Fog)
                }
            }
        }
    }
}
