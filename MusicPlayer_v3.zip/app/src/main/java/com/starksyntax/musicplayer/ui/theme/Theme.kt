package com.starksyntax.musicplayer.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

/** The user's chosen accent colour. Doodle controls read it from here. */
val LocalAccent = compositionLocalOf { Volt }

/** Pen colour that stays readable on top of the accent (black on bright accents, white on dark ones). */
val LocalAccentInk = compositionLocalOf { Color(0xFF0B0B0B) }

fun Color.readableInk(): Color = if (luminance() > 0.18f) Color(0xFF0B0B0B) else Color.White

/** Dark only: deep black canvas, white doodle lines, one loud accent. */
@Composable
fun MusicPlayerTheme(accent: Color, content: @Composable () -> Unit) {
    val ink = remember(accent) { accent.readableInk() }
    val scheme = remember(accent) {
        darkColorScheme(
            primary = accent,
            onPrimary = ink,
            background = Ink,
            onBackground = Chalk,
            surface = Ink,
            onSurface = Chalk,
            surfaceVariant = Ink,
            onSurfaceVariant = Fog,
        )
    }
    CompositionLocalProvider(
        LocalAccent provides accent,
        LocalAccentInk provides ink,
    ) {
        MaterialTheme(
            colorScheme = scheme,
            typography = AppTypography,
            content = content,
        )
    }
}
