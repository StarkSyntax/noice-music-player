package com.starksyntax.musicplayer.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.starksyntax.musicplayer.playback.PlayerViewModel
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.snapshots.SnapshotStateList
import com.starksyntax.musicplayer.data.Playlist
import com.starksyntax.musicplayer.ui.doodle.DoodleIconButton
import com.starksyntax.musicplayer.ui.doodle.Glyph
import androidx.compose.runtime.rememberCoroutineScope
import com.starksyntax.musicplayer.data.Song
import com.starksyntax.musicplayer.data.albumKey
import com.starksyntax.musicplayer.data.songsByArtist
import com.starksyntax.musicplayer.ui.doodle.DoodleToast
import com.starksyntax.musicplayer.ui.theme.Chalk
import com.starksyntax.musicplayer.ui.theme.Ink
import kotlinx.coroutines.delay

@Composable
fun MusicPlayerApp(vm: PlayerViewModel = viewModel()) {
    val context = LocalContext.current

    // --- Permissions ---------------------------------------------------------
    val audioPermission = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
    }
    // Notification permission is asked alongside (Android 13+) but never blocks the app.
    val permissionsToRequest = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    var granted by remember { mutableStateOf(hasPermission(context, audioPermission)) }
    var denied by rememberSaveable { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) {
        granted = hasPermission(context, audioPermission)
        denied = !granted
    }

    // Coming back from Settings (or the system dialog) lands here; also picks up newly added songs.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        granted = hasPermission(context, audioPermission)
        if (granted) vm.refreshLibrary()
    }
    LaunchedEffect(granted) {
        if (granted) vm.refreshLibrary()
    }

    // --- State ---------------------------------------------------------------
    val songs by vm.songs.collectAsStateWithLifecycle()
    val albums by vm.albums.collectAsStateWithLifecycle()
    val artists by vm.artists.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val favoriteIds by vm.favoriteIds.collectAsStateWithLifecycle()
    val accent by vm.accent.collectAsStateWithLifecycle()
    val loaded by vm.libraryLoaded.collectAsStateWithLifecycle()
    val player by vm.state.collectAsStateWithLifecycle()
    val queue by vm.queue.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val sort by vm.sort.collectAsStateWithLifecycle()
    val sleepEndsAt by vm.sleepEndsAt.collectAsStateWithLifecycle()
    // Deliberately not read here: only the progress widgets read the position.
    val positionMs = vm.positionMs.collectAsStateWithLifecycle()

    var showNowPlaying by rememberSaveable { mutableStateOf(false) }
    val routes = rememberSaveable(saver = RouteStackSaver) { mutableStateListOf<Route>() }
    var menuSong by remember { mutableStateOf<Song?>(null) }
    var detailsSong by remember { mutableStateOf<Song?>(null) }
    var pickerSong by remember { mutableStateOf<Song?>(null) }
    var nameTarget by remember { mutableStateOf<NameTarget?>(null) }
    var deleteTarget by remember { mutableStateOf<Playlist?>(null) }
    var showSort by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    val current = player.currentSong
    val route = routes.lastOrNull()

    // Toasts ("Added to queue", ...).
    var toastText by remember { mutableStateOf("") }
    var toastVisible by remember { mutableStateOf(false) }
    var toastTick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        vm.messages.collect {
            toastText = it
            toastVisible = true
            toastTick++
        }
    }
    LaunchedEffect(toastTick) {
        if (toastTick > 0) {
            delay(1700)
            toastVisible = false
        }
    }

    BackHandler(enabled = showNowPlaying) { showNowPlaying = false }
    BackHandler(enabled = !showNowPlaying && routes.isNotEmpty()) { routes.removeAt(routes.lastIndex) }

    val env = remember(player.currentSong?.id, player.isPlaying, favoriteIds) {
        SongEnv(
            currentId = player.currentSong?.id,
            isPlaying = player.isPlaying,
            favorites = favoriteIds,
            onPlay = { queue, index ->
                val tapped = queue.getOrNull(index)
                if (tapped != null && tapped.id == player.currentSong?.id) {
                    showNowPlaying = true
                } else {
                    vm.play(queue, index)
                }
            },
            onPlayAll = { queue, shuffle ->
                vm.playAll(queue, shuffle)
            },
            onMore = { menuSong = it },
        )
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Ink,
        contentColor = Chalk,
    ) {
        Box(Modifier.fillMaxSize()) {
            if (!granted) {
                val activity = context.findActivity()
                val canAskAgain = !denied ||
                    (activity != null && ActivityCompat.shouldShowRequestPermissionRationale(activity, audioPermission))

                PermissionScreen(
                    buttonLabel = if (canAskAgain) "Allow access" else "Open settings",
                    onClick = {
                        if (canAskAgain) {
                            permissionLauncher.launch(permissionsToRequest)
                        } else {
                            openAppSettings(context)
                        }
                    },
                )
            } else {
                val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
                val bottomInset = navBottom + if (current != null) 96.dp else 16.dp

                HomeScreen(
                    songs = songs,
                    loaded = loaded,
                    albums = albums,
                    artists = artists,
                    favorites = favorites,
                    playlists = playlists,
                    sort = sort,
                    env = env,
                    bottomInset = bottomInset,
                    onOpenAlbum = { routes.add(Route.Album(it.key)) },
                    onOpenArtist = { routes.add(Route.Artist(it.name)) },
                    onOpenPlaylist = { routes.add(Route.Playlist(it.id)) },
                    onCreatePlaylist = { nameTarget = NameTarget.New(null) },
                    onOpenSort = { showSort = true },
                    onOpenSettings = { routes.add(Route.Settings) },
                )

                // Album / artist / settings pages sit on top of the tabs.
                AnimatedContent(
                    targetState = route,
                    transitionSpec = { fadeIn(tween(160)) togetherWith fadeOut(tween(120)) },
                    label = "route",
                ) { target ->
                    when (target) {
                        null -> Unit
                        Route.Settings -> SettingsScreen(
                            accent = accent,
                            onAccentChange = vm::setAccent,
                            onBack = { routes.removeAt(routes.lastIndex) },
                        )
                        is Route.Album -> {
                            val album = albums.firstOrNull { it.key == target.key }
                            if (album != null) {
                                DetailScreen(
                                    title = album.name,
                                    subtitle = "${album.artist.uppercase()} · ${trackCountLabel(album.songs.size)}",
                                    artSong = album.songs.first(),
                                    roundArt = false,
                                    songs = album.songs,
                                    env = env,
                                    bottomInset = bottomInset,
                                    onBack = { routes.removeAt(routes.lastIndex) },
                                )
                            }
                        }
                        is Route.Playlist -> {
                            val playlist = playlists.firstOrNull { it.id == target.id }
                            if (playlist != null) {
                                val byId = songs.associateBy { it.id }
                                val list = playlist.songIds.mapNotNull { byId[it] }
                                DetailScreen(
                                    title = playlist.name,
                                    subtitle = trackCountLabel(list.size),
                                    artSong = list.firstOrNull(),
                                    roundArt = false,
                                    songs = list,
                                    env = env,
                                    bottomInset = bottomInset,
                                    onBack = { routes.removeAt(routes.lastIndex) },
                                    emptyText = "Empty for now.\nAdd songs from the ⋮ menu of any song.",
                                    trailing = {
                                        DoodleIconButton(Glyph.Edit, "Rename playlist", {
                                            nameTarget = NameTarget.Rename(playlist.id, playlist.name)
                                        })
                                        DoodleIconButton(Glyph.Trash, "Delete playlist", { deleteTarget = playlist })
                                    },
                                )
                            }
                        }
                        is Route.Artist -> {
                            val list = songsByArtist(songs, target.name)
                            if (list.isNotEmpty()) {
                                DetailScreen(
                                    title = target.name,
                                    subtitle = trackCountLabel(list.size),
                                    artSong = list.first(),
                                    roundArt = true,
                                    songs = list,
                                    env = env,
                                    bottomInset = bottomInset,
                                    onBack = { routes.removeAt(routes.lastIndex) },
                                )
                            }
                        }
                    }
                }

                AnimatedVisibility(
                    visible = current != null,
                    modifier = Modifier.align(Alignment.BottomCenter),
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                ) {
                    if (current != null) {
                        MiniPlayer(
                            song = current,
                            isPlaying = player.isPlaying,
                            positionMs = positionMs,
                            durationMs = player.durationMs,
                            onOpen = { showNowPlaying = true },
                            onTogglePlay = vm::togglePlayPause,
                            onNext = vm::next,
                            modifier = Modifier
                                .padding(horizontal = 12.dp)
                                .navigationBarsPadding()
                                .padding(bottom = 12.dp),
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = showNowPlaying && current != null,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            ) {
                if (current != null) {
                    NowPlayingScreen(
                        song = current,
                        state = player,
                        queue = queue,
                        positionMs = positionMs,
                        isFavorite = current.id in favoriteIds,
                        onClose = { showNowPlaying = false },
                        onTogglePlay = vm::togglePlayPause,
                        onNext = vm::next,
                        onPrevious = vm::previous,
                        onSeek = vm::seekToFraction,
                        onToggleShuffle = vm::toggleShuffle,
                        onCycleRepeat = vm::cycleRepeat,
                        onToggleFavorite = { vm.toggleFavorite(current) },
                        onSkipTo = vm::skipToQueueItem,
                        onRemoveFromQueue = vm::removeFromQueue,
                        onClearUpNext = vm::clearUpNext,
                        sleepActive = sleepEndsAt > System.currentTimeMillis(),
                        onOpenSleep = { showSleep = true },
                    )
                }
            }

            AnimatedVisibility(
                visible = toastVisible,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = if (current != null && !showNowPlaying) 112.dp else 40.dp),
                enter = fadeIn() + slideInVertically(initialOffsetY = { it / 2 }),
                exit = fadeOut(),
            ) {
                DoodleToast(toastText)
            }
        }
    }

    // --- Song menu + dialogs -------------------------------------------------
    menuSong?.let { song ->
        val playlistRoute = route as? Route.Playlist
        SongMenuDialog(
            song = song,
            isFavorite = song.id in favoriteIds,
            onDismiss = { menuSong = null },
            onPlayNext = { vm.playNext(song); menuSong = null },
            onAddToQueue = { vm.addToQueue(song); menuSong = null },
            onAddToPlaylist = { pickerSong = song; menuSong = null },
            onDetails = { detailsSong = song; menuSong = null },
            onOpenAlbum = {
                routes.add(Route.Album(song.albumKey()))
                menuSong = null
            },
            onOpenArtist = { name ->
                routes.add(Route.Artist(name))
                menuSong = null
            },
            onToggleFavorite = { vm.toggleFavorite(song); menuSong = null },
            onShare = { shareSong(context, song); menuSong = null },
            onRemoveFromPlaylist = playlistRoute?.let { r ->
                { vm.removeFromPlaylist(r.id, song); menuSong = null }
            },
        )
    }
    detailsSong?.let { song ->
        TrackDetailsDialog(song = song, loadDetails = vm::trackDetails, onDismiss = { detailsSong = null })
    }
    pickerSong?.let { song ->
        PlaylistPickerDialog(
            playlists = playlists,
            song = song,
            onPick = { vm.addToPlaylist(it.id, song); pickerSong = null },
            onNew = { nameTarget = NameTarget.New(song); pickerSong = null },
            onDismiss = { pickerSong = null },
        )
    }
    nameTarget?.let { target ->
        when (target) {
            is NameTarget.New -> NameDialog(
                title = "New playlist",
                initial = "",
                confirmLabel = "Create",
                onConfirm = { name ->
                    vm.createPlaylist(name, target.firstSong)
                    nameTarget = null
                },
                onDismiss = { nameTarget = null },
            )
            is NameTarget.Rename -> NameDialog(
                title = "Rename playlist",
                initial = target.current,
                confirmLabel = "Save",
                onConfirm = { name ->
                    vm.renamePlaylist(target.id, name)
                    nameTarget = null
                },
                onDismiss = { nameTarget = null },
            )
        }
    }
    deleteTarget?.let { playlist ->
        ConfirmDialog(
            title = "Delete \"${playlist.name}\"?",
            message = "The songs stay on your phone. Only the playlist goes.",
            confirmLabel = "Delete",
            onConfirm = {
                vm.deletePlaylist(playlist.id)
                if (routes.lastOrNull() == Route.Playlist(playlist.id)) routes.removeAt(routes.lastIndex)
                deleteTarget = null
            },
            onDismiss = { deleteTarget = null },
        )
    }
    if (showSort) {
        SortDialog(current = sort, onPick = { vm.setSort(it); showSort = false }, onDismiss = { showSort = false })
    }
    if (showSleep) {
        SleepTimerDialog(
            endsAt = sleepEndsAt,
            onPick = { vm.setSleepTimer(it); showSleep = false },
            onDismiss = { showSleep = false },
        )
    }
}

private sealed interface NameTarget {
    data class New(val firstSong: Song?) : NameTarget
    data class Rename(val id: Long, val current: String) : NameTarget
}

/** Lets the screen stack survive rotation. */
private val RouteStackSaver = listSaver<SnapshotStateList<Route>, String>(
    save = { stack ->
        stack.map { r ->
            when (r) {
                Route.Settings -> "S"
                is Route.Album -> "A:" + r.key
                is Route.Artist -> "R:" + r.name
                is Route.Playlist -> "P:" + r.id
            }
        }
    },
    restore = { saved ->
        mutableStateListOf<Route>().apply {
            saved.forEach { code ->
                when {
                    code == "S" -> add(Route.Settings)
                    code.startsWith("A:") -> add(Route.Album(code.drop(2)))
                    code.startsWith("R:") -> add(Route.Artist(code.drop(2)))
                    code.startsWith("P:") -> code.drop(2).toLongOrNull()?.let { add(Route.Playlist(it)) }
                }
            }
        }
    },
)

private fun shareSong(context: Context, song: Song) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "audio/*"
        putExtra(Intent.EXTRA_STREAM, song.uri)
        putExtra(Intent.EXTRA_SUBJECT, song.title)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        context.startActivity(Intent.createChooser(send, "Share ${song.title}"))
    } catch (e: Exception) {
        // No app can take it; nothing useful to do.
    }
}

private fun hasPermission(context: Context, permission: String): Boolean =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

private fun openAppSettings(context: Context) {
    val intent = Intent(
        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
        Uri.fromParts("package", context.packageName, null),
    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
