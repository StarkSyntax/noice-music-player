package com.starksyntax.musicplayer.playback

import androidx.compose.runtime.Immutable
import androidx.media3.common.Player
import com.starksyntax.musicplayer.data.Song

/**
 * Everything the UI needs about playback except the position, which ticks
 * several times a second and lives in its own flow so the list doesn't recompose.
 */
@Immutable
data class PlayerUiState(
    val currentSong: Song? = null,
    val isPlaying: Boolean = false,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val queueIndex: Int = 0,
)
