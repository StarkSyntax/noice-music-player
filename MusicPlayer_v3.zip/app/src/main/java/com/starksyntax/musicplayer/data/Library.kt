package com.starksyntax.musicplayer.data

import androidx.compose.runtime.Immutable

/** Songs grouped by album name (so one movie = one album, even if the files sit in different folders). */
@Immutable
data class Album(
    val key: String,
    val name: String,
    val artist: String,
    /** Any song's albumId, used to load the cover. */
    val artworkAlbumId: Long,
    val songs: List<Song>,
)

/** Songs grouped by artist. A song with several credited artists appears under each of them. */
@Immutable
data class Artist(
    val name: String,
    val artworkAlbumId: Long,
    val songs: List<Song>,
    val albumCount: Int,
)

/** File-level facts for the details dialog. */
@Immutable
data class TrackDetails(
    val song: Song,
    val fileName: String = "",
    val folder: String = "",
    val sizeBytes: Long = 0L,
    val mimeType: String = "",
    val year: Int = 0,
    val bitrateBps: Int = 0,
    val addedSeconds: Long = 0L,
)

const val UNKNOWN_ALBUM = "Unknown album"

/** "A, B; C" -> [A, B, C]. Tags have no standard separator, so we split on the common ones. */
fun splitArtists(raw: String): List<String> {
    val parts = raw.split(',', ';', '/', '&')
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .distinctBy { it.lowercase() }
    return parts.ifEmpty { listOf(raw.trim().ifEmpty { "Unknown artist" }) }
}

fun Song.albumKey(): String = album.trim().lowercase().ifEmpty { UNKNOWN_ALBUM.lowercase() }

fun buildAlbums(songs: List<Song>): List<Album> =
    songs.groupBy { it.albumKey() }
        .map { (key, list) ->
            // Play order inside an album: track number, then title.
            val ordered = list.sortedWith(compareBy<Song> { if (it.track > 0) it.track else Int.MAX_VALUE }
                .thenBy { it.title.lowercase() })
            val artists = ordered.flatMap { splitArtists(it.artist) }.distinctBy { it.lowercase() }
            Album(
                key = key,
                name = ordered.first().album.ifBlank { UNKNOWN_ALBUM },
                artist = if (artists.size == 1) artists[0] else "Various artists",
                artworkAlbumId = ordered.first().albumId,
                songs = ordered,
            )
        }
        .sortedBy { it.name.lowercase() }

fun buildArtists(songs: List<Song>): List<Artist> {
    val map = LinkedHashMap<String, MutableList<Song>>()
    val display = HashMap<String, String>()
    for (song in songs) {
        for (name in splitArtists(song.artist)) {
            val key = name.lowercase()
            display.putIfAbsent(key, name)
            map.getOrPut(key) { ArrayList() }.add(song)
        }
    }
    return map.map { (key, list) ->
        Artist(
            name = display.getValue(key),
            artworkAlbumId = list.first().albumId,
            songs = list,
            albumCount = list.map { it.albumKey() }.distinct().size,
        )
    }.sortedBy { it.name.lowercase() }
}

fun songsByArtist(songs: List<Song>, artistName: String): List<Song> =
    songs.filter { s -> splitArtists(s.artist).any { it.equals(artistName, ignoreCase = true) } }

/** A user-made playlist. Songs are stored by id, in the order they were added. */
@Immutable
data class Playlist(val id: Long, val name: String, val songIds: List<Long>)

enum class SortOrder(val label: String) {
    Title("Title  A–Z"),
    Artist("Artist  A–Z"),
    Recent("Recently added"),
    Longest("Longest first"),
}

fun List<Song>.sortedFor(order: SortOrder): List<Song> = when (order) {
    SortOrder.Title -> sortedBy { it.title.lowercase() }
    SortOrder.Artist -> sortedWith(compareBy<Song> { it.artist.lowercase() }.thenBy { it.title.lowercase() })
    SortOrder.Recent -> sortedByDescending { it.added }
    SortOrder.Longest -> sortedByDescending { it.durationMs }
}
