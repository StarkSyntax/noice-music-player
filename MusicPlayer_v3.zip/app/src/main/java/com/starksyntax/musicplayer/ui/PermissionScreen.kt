package com.starksyntax.musicplayer.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.starksyntax.musicplayer.R
import com.starksyntax.musicplayer.ui.doodle.DoodleButton
import com.starksyntax.musicplayer.ui.theme.Chalk
import com.starksyntax.musicplayer.ui.theme.Fog
import com.starksyntax.musicplayer.ui.theme.LocalAccentInk

@Composable
fun PermissionScreen(
    buttonLabel: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.Start,
    ) {
        Image(
            painter = painterResource(R.drawable.noice_logo),
            contentDescription = "NOICE",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxWidth(0.62f),
        )
        Spacer(Modifier.height(28.dp))
        Text(
            text = "Let the\nmusic in.",
            style = MaterialTheme.typography.displaySmall.copy(fontSize = 44.sp, lineHeight = 48.sp),
            color = Chalk,
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = "Allow access to audio files so NOICE can find the songs on your phone. " +
                "Everything stays on your device.",
            style = MaterialTheme.typography.bodyLarge,
            color = Fog,
        )
        Spacer(Modifier.height(32.dp))
        DoodleButton(onClick = onClick, filled = true, seed = 6) {
            Text(buttonLabel.uppercase(), style = MaterialTheme.typography.labelMedium, color = LocalAccentInk.current)
        }
    }
}
