package com.starksyntax.musicplayer.ui.doodle

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// The whole "hand-drawn" look comes from three tricks:
//   1. Every shape is a sampled outline whose points are nudged by deterministic noise
//      (same seed = same wobble, so nothing shimmers between frames).
//   2. Outlines are smoothed with Catmull-Rom curves so the wobble reads as a pen line.
//   3. Pen details: a thin second line inside the outline, and short diagonal hatch strokes.

/** Deterministic pseudo-random value in [-1, 1] for a (seed, index) pair. */
internal fun noise(seed: Int, index: Int): Float {
    var h = seed * 374761393 + index * 668265263 + 0x5bd1e995
    h = (h xor (h ushr 13)) * 1274126177
    h = h xor (h ushr 16)
    return (h and 0xFFFF) / 32767.5f - 1f
}

internal fun jitter(points: List<Offset>, amount: Float, seed: Int): List<Offset> =
    points.mapIndexed { i, p ->
        Offset(p.x + noise(seed, i * 2) * amount, p.y + noise(seed, i * 2 + 1) * amount)
    }

/** Smooth curve through [points] (Catmull-Rom converted to cubic Beziers). */
internal fun smoothPath(points: List<Offset>, closed: Boolean): Path {
    val path = Path()
    val n = points.size
    if (n == 0) return path
    path.moveTo(points[0].x, points[0].y)
    if (n == 1) return path
    if (n == 2 && !closed) {
        path.lineTo(points[1].x, points[1].y)
        return path
    }
    val segments = if (closed) n else n - 1
    for (i in 0 until segments) {
        val p0 = points[if (closed) (i - 1 + n) % n else max(i - 1, 0)]
        val p1 = points[i]
        val p2 = points[(i + 1) % n]
        val p3 = points[if (closed) (i + 2) % n else min(i + 2, n - 1)]
        path.cubicTo(
            p1.x + (p2.x - p0.x) / 6f, p1.y + (p2.y - p0.y) / 6f,
            p2.x - (p3.x - p1.x) / 6f, p2.y - (p3.y - p1.y) / 6f,
            p2.x, p2.y,
        )
    }
    if (closed) path.close()
    return path
}

/** Straight segments through [points]: keeps corners sharp (arrows, ticks, triangles). */
internal fun linePath(points: List<Offset>, closed: Boolean): Path {
    val path = Path()
    if (points.isEmpty()) return path
    path.moveTo(points[0].x, points[0].y)
    for (i in 1 until points.size) path.lineTo(points[i].x, points[i].y)
    if (closed) path.close()
    return path
}

/** Splits long segments so jitter can make them wobble instead of looking ruler-straight. */
internal fun subdivide(points: List<Offset>, maxLen: Float, closed: Boolean): List<Offset> {
    if (points.size < 2) return points
    val out = ArrayList<Offset>()
    val segments = if (closed) points.size else points.size - 1
    for (i in 0 until segments) {
        val a = points[i]
        val b = points[(i + 1) % points.size]
        val n = max(1, (hypot(b.x - a.x, b.y - a.y) / maxLen).toInt())
        for (k in 0 until n) {
            val t = k / n.toFloat()
            out.add(Offset(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t))
        }
    }
    if (!closed) out.add(points.last())
    return out
}

/** Points walking clockwise around a rounded rectangle. A radius >= half the height gives a pill or circle. */
internal fun roundRectPoints(
    left: Float,
    top: Float,
    right: Float,
    bottom: Float,
    radius: Float,
    step: Float,
): List<Offset> {
    val r = radius.coerceIn(0f, min(right - left, bottom - top) / 2f)
    val pts = ArrayList<Offset>()

    fun line(x0: Float, y0: Float, x1: Float, y1: Float) {
        val len = hypot(x1 - x0, y1 - y0)
        if (len < 0.5f) return
        val n = max(1, (len / step).toInt())
        for (i in 0 until n) {
            val t = i / n.toFloat()
            pts.add(Offset(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t))
        }
    }

    fun arc(cx: Float, cy: Float, startDeg: Float) {
        if (r < 0.5f) {
            pts.add(Offset(cx, cy))
            return
        }
        val n = 5
        for (i in 0 until n) {
            val a = Math.toRadians((startDeg + 90f * i / n).toDouble())
            pts.add(Offset(cx + r * cos(a).toFloat(), cy + r * sin(a).toFloat()))
        }
    }

    line(left + r, top, right - r, top)
    arc(right - r, top + r, 270f)
    line(right, top + r, right, bottom - r)
    arc(right - r, bottom - r, 0f)
    line(right - r, bottom, left + r, bottom)
    arc(left + r, bottom - r, 90f)
    line(left, bottom - r, left, top + r)
    arc(left + r, top + r, 180f)
    return pts
}

internal fun doodleCirclePath(cx: Float, cy: Float, r: Float, wobble: Float, seed: Int): Path =
    smoothPath(
        jitter(roundRectPoints(cx - r, cy - r, cx + r, cy + r, r, step = r * 2f), wobble, seed),
        closed = true,
    )

/**
 * Draws a hand-drawn rounded rectangle behind the content.
 *
 * @param line  outline colour
 * @param fill  body colour, or null for outline only
 * @param ink   colour of the thin inner sketch line and the hatching
 * @param hatch short diagonal strokes along the left and bottom, like the NOICE logo
 * @param sketch thin second line inside the outline
 * @param seed  different seeds give different wobble
 */
fun Modifier.doodleFrame(
    line: Color,
    fill: Color? = null,
    ink: Color = line,
    radius: Dp = 16.dp,
    stroke: Dp = 2.dp,
    hatch: Boolean = false,
    sketch: Boolean = true,
    seed: Int = 1,
): Modifier = drawBehind {
    drawDoodleFrame(line, fill, ink, radius.toPx(), stroke.toPx(), hatch, sketch, seed)
}

internal fun DrawScope.drawDoodleFrame(
    line: Color,
    fill: Color?,
    ink: Color,
    radiusPx: Float,
    strokePx: Float,
    hatch: Boolean,
    sketch: Boolean,
    seed: Int,
) {
    val w = size.width
    val h = size.height
    val pad = strokePx * 1.2f
    if (w < pad * 6f || h < pad * 6f) return

    val wobble = strokePx * 0.45f
    val step = 26.dp.toPx()
    val penStyle = Stroke(width = strokePx, cap = StrokeCap.Round, join = StrokeJoin.Round)

    val outer = smoothPath(
        jitter(roundRectPoints(pad, pad, w - pad, h - pad, radiusPx, step), wobble, seed),
        closed = true,
    )
    if (fill != null) drawPath(outer, fill)
    drawPath(outer, line, style = penStyle)

    val inset = strokePx * 3.4f
    val minSide = min(w, h)
    if (sketch && minSide > inset * 5f) {
        val inner = smoothPath(
            jitter(
                roundRectPoints(
                    pad + inset, pad + inset, w - pad - inset, h - pad - inset,
                    max(radiusPx - inset, 2f), step,
                ),
                wobble,
                seed + 11,
            ),
            closed = true,
        )
        drawPath(
            inner,
            ink.copy(alpha = 0.6f),
            style = Stroke(width = strokePx * 0.5f, cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
    }

    if (hatch && minSide > 30.dp.toPx()) {
        val m = inset * 1.35f
        drawHatch(ink.copy(alpha = 0.7f), strokePx * 0.5f, pad + m, pad + m, w - pad - m, h - pad - m, seed)
    }
}

/** Short diagonal pen strokes: a cluster down the left edge and a few along the bottom. */
private fun DrawScope.drawHatch(
    color: Color,
    strokePx: Float,
    left: Float,
    top: Float,
    right: Float,
    bottom: Float,
    seed: Int,
) {
    val w = right - left
    val h = bottom - top
    if (w <= 0f || h <= 0f) return
    val len = min(min(w, h) * 0.24f, 14.dp.toPx())
    val gap = len * 0.8f

    var y = top + len
    var i = 0
    while (y < top + h * 0.62f && i < 7) {
        val l = len * (0.8f + 0.25f * noise(seed, 100 + i))
        drawLine(color, Offset(left, y), Offset(left + l * 0.55f, y - l), strokePx, StrokeCap.Round)
        y += gap
        i++
    }

    var x = left + w * 0.45f
    var j = 0
    while (x < right - len && j < 4) {
        val l = len * (0.7f + 0.25f * noise(seed, 200 + j))
        drawLine(color, Offset(x, bottom), Offset(x + l * 0.55f, bottom - l * 0.8f), strokePx, StrokeCap.Round)
        x += gap
        j++
    }
}

/** A wavy hand-drawn underline along the bottom edge of the content. */
fun Modifier.doodleUnderline(
    color: Color,
    stroke: Dp = 2.dp,
    amplitude: Dp = 1.6.dp,
    seed: Int = 5,
): Modifier = drawBehind {
    val w = size.width
    val strokePx = stroke.toPx()
    val amp = amplitude.toPx()
    val y = size.height - strokePx * 1.5f
    val n = max(2, (w / 9.dp.toPx()).toInt())
    val pts = (0..n).map { i ->
        Offset(w * i / n, y + sin(i * 1.7f + seed) * amp + noise(seed, i) * amp * 0.4f)
    }
    drawPath(
        smoothPath(pts, closed = false),
        color,
        style = Stroke(width = strokePx, cap = StrokeCap.Round, join = StrokeJoin.Round),
    )
}
