package com.starksyntax.musicplayer.data

import android.content.Context
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Reads the device's music library from MediaStore. */
class MusicRepository(private val context: Context) {

    suspend fun loadSongs(): List<Song> = withContext(Dispatchers.IO) {
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.DATE_ADDED,
        )

        // Real music only: skips ringtones, notification sounds and very short clips.
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND " +
            "${MediaStore.Audio.Media.DURATION} >= ?"
        val selectionArgs = arrayOf(MIN_DURATION_MS.toString())

        val songs = ArrayList<Song>()
        context.contentResolver.query(collection, projection, selection, selectionArgs, null)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val trackCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val addedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)

            while (cursor.moveToNext()) {
                songs += Song(
                    id = cursor.getLong(idCol),
                    title = cursor.getString(titleCol).cleanOr("Unknown title"),
                    artist = cursor.getString(artistCol).cleanOr("Unknown artist"),
                    album = cursor.getString(albumCol).cleanOr(""),
                    albumId = cursor.getLong(albumIdCol),
                    durationMs = cursor.getLong(durationCol),
                    // MediaStore stores disc * 1000 + track.
                    track = cursor.getInt(trackCol) % 1000,
                    added = cursor.getLong(addedCol),
                )
            }
        }

        songs.sortedBy { it.title.lowercase() }
    }

    /** Extra file facts for the "Track details" dialog. */
    suspend fun loadDetails(song: Song): TrackDetails = withContext(Dispatchers.IO) {
        val projection = buildList {
            add(MediaStore.Audio.Media.DISPLAY_NAME)
            add(MediaStore.Audio.Media.SIZE)
            add(MediaStore.Audio.Media.MIME_TYPE)
            add(MediaStore.Audio.Media.YEAR)
            add(MediaStore.Audio.Media.DATE_ADDED)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) add(MediaStore.Audio.Media.RELATIVE_PATH)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) add(MediaStore.Audio.Media.BITRATE)
        }.toTypedArray()

        var details = TrackDetails(song = song)
        try {
            context.contentResolver.query(song.uri, projection, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    fun str(name: String): String? {
                        val i = c.getColumnIndex(name)
                        return if (i >= 0) c.getString(i) else null
                    }
                    fun long(name: String): Long {
                        val i = c.getColumnIndex(name)
                        return if (i >= 0) c.getLong(i) else 0L
                    }
                    details = TrackDetails(
                        song = song,
                        fileName = str(MediaStore.Audio.Media.DISPLAY_NAME).orEmpty(),
                        folder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            str(MediaStore.Audio.Media.RELATIVE_PATH).orEmpty()
                        } else {
                            ""
                        },
                        sizeBytes = long(MediaStore.Audio.Media.SIZE),
                        mimeType = str(MediaStore.Audio.Media.MIME_TYPE).orEmpty(),
                        year = long(MediaStore.Audio.Media.YEAR).toInt(),
                        bitrateBps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            long(MediaStore.Audio.Media.BITRATE).toInt()
                        } else {
                            0
                        },
                        addedSeconds = long(MediaStore.Audio.Media.DATE_ADDED),
                    )
                }
            }
        } catch (e: Exception) {
            // Fall back to what we already know about the song.
        }
        details
    }

    private fun String?.cleanOr(fallback: String): String {
        val value = this?.trim().orEmpty()
        // MediaStore reports missing tags as "<unknown>".
        return if (value.isBlank() || value == "<unknown>") fallback else value
    }

    private companion object {
        const val MIN_DURATION_MS = 10_000L
    }
}
