package com.starksyntax.musicplayer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.starksyntax.musicplayer.data.Song
import com.starksyntax.musicplayer.ui.doodle.DoodleButton
import com.starksyntax.musicplayer.ui.doodle.DoodleIcon
import com.starksyntax.musicplayer.ui.doodle.DoodleIconButton
import com.starksyntax.musicplayer.ui.doodle.EqualizerBars
import com.starksyntax.musicplayer.ui.doodle.Glyph
import com.starksyntax.musicplayer.ui.doodle.bouncyClickable
import com.starksyntax.musicplayer.ui.doodle.doodleUnderline
import com.starksyntax.musicplayer.ui.theme.Chalk
import com.starksyntax.musicplayer.ui.theme.Fog
import com.starksyntax.musicplayer.ui.theme.LocalAccent
import com.starksyntax.musicplayer.ui.theme.LocalAccentInk

/** Everything a list of songs needs to know about the outside world. */
@Immutable
class SongEnv(
    val currentId: Long?,
    val isPlaying: Boolean,
    val favorites: Set<Long>,
    /** Tap on a row: play [queue] from [index]. */
    val onPlay: (queue: List<Song>, index: Int) -> Unit,
    /** PLAY (in order) or SHUFFLE (random) over a whole list. */
    val onPlayAll: (queue: List<Song>, shuffle: Boolean) -> Unit,
    val onMore: (Song) -> Unit,
)

@Composable
fun SongList(
    songs: List<Song>,
    env: SongEnv,
    bottomInset: Dp,
    emptyText: String,
    modifier: Modifier = Modifier,
    showActions: Boolean = true,
    header: (@Composable () -> Unit)? = null,
) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomInset)) {
        if (header != null) item(key = "header") { header() }
        if (songs.isEmpty()) {
            item(key = "empty") { EmptyNote(emptyText, Modifier.padding(top = 56.dp)) }
        } else {
            if (showActions) {
                item(key = "actions") {
                    PlayShuffleBar(
                        onPlay = { env.onPlayAll(songs, false) },
                        onShuffle = { env.onPlayAll(songs, true) },
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    )
                }
            }
            itemsIndexed(songs, key = { _, song -> song.id }) { index, song ->
                SongRow(
                    song = song,
                    isCurrent = song.id == env.currentId,
                    isPlaying = env.isPlaying,
                    isFavorite = song.id in env.favorites,
                    onClick = { env.onPlay(songs, index) },
                    onMore = { env.onMore(song) },
                )
            }
        }
    }
}

/** PLAY = whole list in order, SHUFFLE = whole list in random order. */
@Composable
fun PlayShuffleBar(onPlay: () -> Unit, onShuffle: () -> Unit, modifier: Modifier = Modifier) {
    val ink = LocalAccentInk.current
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        DoodleButton(onClick = onPlay, modifier = Modifier.weight(1f), filled = true, seed = 3) {
            DoodleIcon(Glyph.Play, tint = ink, size = 18.dp)
            Spacer(Modifier.width(8.dp))
            Text("PLAY", style = MaterialTheme.typography.labelMedium, color = ink)
        }
        DoodleButton(onClick = onShuffle, modifier = Modifier.weight(1f), filled = false, seed = 5) {
            DoodleIcon(Glyph.Shuffle, tint = Chalk, size = 18.dp)
            Spacer(Modifier.width(8.dp))
            Text("SHUFFLE", style = MaterialTheme.typography.labelMedium, color = Chalk)
        }
    }
}

@Composable
fun SongRow(
    song: Song,
    isCurrent: Boolean,
    isPlaying: Boolean,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onMore: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val accent = LocalAccent.current
    Row(
        modifier
            .fillMaxWidth()
            .bouncyClickable(pressedScale = 0.97f, onClick = onClick)
            .doodleUnderline(Color(0x1FFFFFFF), stroke = 1.dp, amplitude = 1.dp, seed = (song.id % 97).toInt())
            .padding(start = 16.dp, top = 8.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
            ArtTile(song, Modifier.fillMaxSize(), radius = 12.dp, sizePx = 160, seed = (song.id % 13).toInt())
            if (isCurrent) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(5.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xAA000000)),
                    contentAlignment = Alignment.Center,
                ) {
                    EqualizerBars(playing = isPlaying, color = accent, modifier = Modifier.size(20.dp))
                }
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = song.title,
                style = MaterialTheme.typography.titleMedium,
                color = if (isCurrent) accent else Chalk,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = "${song.artist}  ·  ${formatDuration(song.durationMs)}",
                style = MaterialTheme.typography.bodyMedium,
                color = Fog,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (isFavorite) {
            DoodleIcon(Glyph.Heart, tint = accent, size = 16.dp, filled = true)
        }
        DoodleIconButton(Glyph.More, "More options for ${song.title}", onMore, tint = Fog)
    }
}

@Composable
fun EmptyNote(text: String, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(horizontal = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        DoodleIcon(Glyph.Note, tint = Fog, size = 44.dp)
        Spacer(Modifier.height(14.dp))
        Text(
            text,
            style = MaterialTheme.typography.bodyLarge,
            color = Fog,
            textAlign = TextAlign.Center,
        )
    }
}
