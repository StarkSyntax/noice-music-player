package com.starksyntax.musicplayer.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.starksyntax.musicplayer.data.Album
import com.starksyntax.musicplayer.data.Artist
import com.starksyntax.musicplayer.data.Playlist
import com.starksyntax.musicplayer.data.Song
import com.starksyntax.musicplayer.data.SortOrder
import com.starksyntax.musicplayer.data.sortedFor
import com.starksyntax.musicplayer.ui.doodle.DoodleIcon
import com.starksyntax.musicplayer.ui.doodle.DoodleIconButton
import com.starksyntax.musicplayer.ui.doodle.DoodleTabs
import com.starksyntax.musicplayer.ui.doodle.Glyph
import com.starksyntax.musicplayer.ui.doodle.doodleFrame
import com.starksyntax.musicplayer.ui.doodle.doodleUnderline
import com.starksyntax.musicplayer.ui.theme.Chalk
import com.starksyntax.musicplayer.ui.theme.Fog
import com.starksyntax.musicplayer.ui.theme.LocalAccent
import kotlinx.coroutines.launch

private val TabLabels = listOf("ALBUMS", "LIBRARY", "ARTISTS", "FAVORITES", "PLAYLISTS")
private const val LIBRARY_PAGE = 1

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    songs: List<Song>,
    loaded: Boolean,
    albums: List<Album>,
    artists: List<Artist>,
    favorites: List<Song>,
    playlists: List<Playlist>,
    sort: SortOrder,
    env: SongEnv,
    bottomInset: Dp,
    onOpenAlbum: (Album) -> Unit,
    onOpenArtist: (Artist) -> Unit,
    onOpenPlaylist: (Playlist) -> Unit,
    onCreatePlaylist: () -> Unit,
    onOpenSort: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val accent = LocalAccent.current
    val pager = rememberPagerState(initialPage = LIBRARY_PAGE) { TabLabels.size }
    val scope = rememberCoroutineScope()
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.doodleUnderline(accent, stroke = 3.dp, amplitude = 2.dp, seed = 2).padding(bottom = 10.dp)) {
                Text("NOICE", style = MaterialTheme.typography.displaySmall, color = Chalk)
            }
            Spacer(Modifier.weight(1f))
            DoodleIconButton(
                glyph = Glyph.Search,
                description = "Search",
                onClick = {
                    searching = !searching
                    if (!searching) query = ""
                    else scope.launch { pager.animateScrollToPage(LIBRARY_PAGE) }
                },
                tint = if (searching) accent else Chalk,
            )
            DoodleIconButton(Glyph.Sort, "Sort library", onOpenSort)
            DoodleIconButton(Glyph.Settings, "Settings", onOpenSettings)
        }

        if (searching) {
            SearchField(query = query, onChange = { query = it })
        }

        DoodleTabs(
            labels = TabLabels,
            selectedIndex = pager.currentPage,
            onSelect = { scope.launch { pager.animateScrollToPage(it) } },
        )

        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
            when (page) {
                0 -> AlbumsTab(albums, loaded, bottomInset, onOpenAlbum)
                1 -> {
                    val shown = remember(songs, query, sort) {
                        val q = query.trim()
                        val sorted = songs.sortedFor(sort)
                        if (q.isEmpty()) sorted else sorted.filter {
                            it.title.contains(q, ignoreCase = true) ||
                                it.artist.contains(q, ignoreCase = true) ||
                                it.album.contains(q, ignoreCase = true)
                        }
                    }
                    SongList(
                        songs = shown,
                        env = env,
                        bottomInset = bottomInset,
                        emptyText = when {
                            !loaded -> "Looking for songs…"
                            query.isNotBlank() -> "Nothing matches “${query.trim()}”."
                            else -> "No music found on this phone."
                        },
                    )
                }
                2 -> ArtistsTab(artists, loaded, bottomInset, onOpenArtist)
                4 -> {
                    val byId = remember(songs) { songs.associateBy { it.id } }
                    PlaylistsTab(playlists, byId, bottomInset, onOpenPlaylist, onCreatePlaylist)
                }
                else -> SongList(
                    songs = favorites,
                    env = env,
                    bottomInset = bottomInset,
                    emptyText = "Nothing here yet.\nTap the heart on a song to keep it close.",
                )
            }
        }
    }
}

@Composable
private fun SearchField(query: String, onChange: (String) -> Unit) {
    val accent = LocalAccent.current
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .doodleFrame(line = Chalk, ink = Chalk, radius = 18.dp, stroke = 1.6.dp, sketch = false, seed = 8)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        DoodleIcon(Glyph.Search, tint = Fog, size = 20.dp)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (query.isEmpty()) {
                Text("Search songs, artists, albums", style = MaterialTheme.typography.bodyLarge, color = Fog)
            }
            BasicTextField(
                value = query,
                onValueChange = onChange,
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyLarge.copy(color = Chalk),
                cursorBrush = SolidColor(accent),
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
            )
        }
        if (query.isNotEmpty()) {
            DoodleIconButton(Glyph.Close, "Clear search", { onChange("") }, iconSize = 18.dp, hitSize = 32.dp)
        }
    }
}
