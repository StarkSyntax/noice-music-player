package com.starksyntax.musicplayer

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.starksyntax.musicplayer.playback.PlayerViewModel
import com.starksyntax.musicplayer.ui.MusicPlayerApp
import com.starksyntax.musicplayer.ui.theme.MusicPlayerTheme

class MainActivity : ComponentActivity() {
    private val viewModel: PlayerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Dark-only app: light status/navigation icons over a transparent bar.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent {
            val accent by viewModel.accent.collectAsStateWithLifecycle()
            MusicPlayerTheme(accent = accent) {
                MusicPlayerApp(viewModel)
            }
        }
    }
}
