package com.starksyntax.musicplayer.ui

fun formatDuration(ms: Long): String {
    val totalSeconds = ms.coerceAtLeast(0L) / 1000L
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "$minutes:${seconds.toString().padStart(2, '0')}"
}

fun trackCountLabel(count: Int): String = if (count == 1) "1 TRACK" else "$count TRACKS"

fun resultCountLabel(count: Int): String = if (count == 1) "1 RESULT" else "$count RESULTS"

fun formatSize(bytes: Long): String = when {
    bytes <= 0L -> ""
    bytes < 1024L * 1024L -> "${bytes / 1024L} KB"
    else -> String.format(java.util.Locale.US, "%.1f MB", bytes / 1024.0 / 1024.0)
}

fun formatDate(epochSeconds: Long): String =
    if (epochSeconds <= 0L) "" else java.text.DateFormat.getDateInstance().format(java.util.Date(epochSeconds * 1000L))

fun albumCountLabel(count: Int): String = if (count == 1) "1 ALBUM" else "$count ALBUMS"
