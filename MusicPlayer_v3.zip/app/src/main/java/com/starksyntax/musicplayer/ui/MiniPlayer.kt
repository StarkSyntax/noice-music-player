package com.starksyntax.musicplayer.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.starksyntax.musicplayer.data.Song
import com.starksyntax.musicplayer.ui.doodle.DoodleIconButton
import com.starksyntax.musicplayer.ui.doodle.Glyph
import com.starksyntax.musicplayer.ui.doodle.doodleFrame
import com.starksyntax.musicplayer.ui.theme.Chalk
import com.starksyntax.musicplayer.ui.theme.Fog
import com.starksyntax.musicplayer.ui.theme.Ink
import com.starksyntax.musicplayer.ui.theme.LocalAccent

@Composable
fun MiniPlayer(
    song: Song,
    isPlaying: Boolean,
    positionMs: State<Long>,
    durationMs: Long,
    onOpen: () -> Unit,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val accent = LocalAccent.current
    Column(
        modifier
            .fillMaxWidth()
            .doodleFrame(line = Chalk, fill = Ink, ink = Chalk, radius = 24.dp, stroke = 2.dp, seed = 12)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onOpen)
            .padding(start = 14.dp, end = 6.dp, top = 12.dp, bottom = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ArtTile(song, Modifier.size(46.dp), radius = 12.dp, sizePx = 160, seed = 15)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    song.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = Chalk,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    song.artist,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Fog,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            DoodleIconButton(
                glyph = if (isPlaying) Glyph.Pause else Glyph.Play,
                description = if (isPlaying) "Pause" else "Play",
                onClick = onTogglePlay,
                tint = accent,
                iconSize = 28.dp,
            )
            DoodleIconButton(Glyph.Next, "Next", onNext, iconSize = 24.dp)
        }
        Spacer(Modifier.height(6.dp))
        // Progress is read inside the draw block, so only this line redraws as the song plays.
        androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(4.dp).padding(end = 8.dp)) {
            val y = size.height / 2f
            val w = size.width
            drawLine(Color(0x33FFFFFF), Offset(0f, y), Offset(w, y), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
            val f = if (durationMs > 0L) (positionMs.value.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
            if (f > 0f) drawLine(accent, Offset(0f, y), Offset(w * f, y), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
        }
    }
}
