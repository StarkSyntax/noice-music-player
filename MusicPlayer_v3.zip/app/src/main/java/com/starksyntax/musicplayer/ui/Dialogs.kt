package com.starksyntax.musicplayer.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import com.starksyntax.musicplayer.data.Playlist
import com.starksyntax.musicplayer.data.SortOrder
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.starksyntax.musicplayer.data.Song
import com.starksyntax.musicplayer.data.TrackDetails
import com.starksyntax.musicplayer.data.splitArtists
import com.starksyntax.musicplayer.ui.doodle.DoodleButton
import com.starksyntax.musicplayer.ui.doodle.DoodleIcon
import com.starksyntax.musicplayer.ui.doodle.Glyph
import com.starksyntax.musicplayer.ui.doodle.bouncyClickable
import com.starksyntax.musicplayer.ui.doodle.doodleFrame
import com.starksyntax.musicplayer.ui.theme.Chalk
import com.starksyntax.musicplayer.ui.theme.Fog
import com.starksyntax.musicplayer.ui.theme.Ink
import com.starksyntax.musicplayer.ui.theme.LocalAccent
import com.starksyntax.musicplayer.ui.theme.LocalAccentInk

@Composable
private fun DoodlePanel(onDismiss: () -> Unit, seed: Int, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .doodleFrame(line = Chalk, fill = Ink, ink = Chalk, radius = 26.dp, stroke = 2.dp, hatch = true, seed = seed)
                .padding(horizontal = 26.dp, vertical = 24.dp),
        ) {
            content()
        }
    }
}

/** The ⋮ menu. */
@Composable
fun SongMenuDialog(
    song: Song,
    isFavorite: Boolean,
    onDismiss: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onDetails: () -> Unit,
    onOpenAlbum: () -> Unit,
    onOpenArtist: (String) -> Unit,
    onToggleFavorite: () -> Unit,
    onShare: () -> Unit,
    onRemoveFromPlaylist: (() -> Unit)? = null,
) {
    val accent = LocalAccent.current
    DoodlePanel(onDismiss, seed = 4) {
        Text(
            song.title,
            style = MaterialTheme.typography.titleLarge,
            color = Chalk,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            song.artist,
            style = MaterialTheme.typography.bodyMedium,
            color = Fog,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(10.dp))
        Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
            MenuItem(Glyph.Next, "Play next", onClick = onPlayNext)
            MenuItem(Glyph.Queue, "Add to queue", onClick = onAddToQueue)
            MenuItem(Glyph.Lines, "Add to playlist", onClick = onAddToPlaylist)
            if (onRemoveFromPlaylist != null) {
                MenuItem(Glyph.Close, "Remove from this playlist", onClick = onRemoveFromPlaylist)
            }
            MenuItem(
                glyph = Glyph.Heart,
                label = if (isFavorite) "Remove from favorites" else "Add to favorites",
                filled = isFavorite,
                tint = accent,
                onClick = onToggleFavorite,
            )
            MenuItem(Glyph.Info, "Track details", onClick = onDetails)
            MenuItem(Glyph.Album, "Album · ${song.album.ifBlank { "Unknown album" }}", onClick = onOpenAlbum)
            splitArtists(song.artist).take(3).forEach { name ->
                MenuItem(Glyph.Artist, "Artist · $name", onClick = { onOpenArtist(name) })
            }
            MenuItem(Glyph.Share, "Share", onClick = onShare)
        }
    }
}

/** Asks for a name (new playlist / rename). */
@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val accent = LocalAccent.current
    val ink = LocalAccentInk.current
    var text by remember { mutableStateOf(initial) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    val submit = { if (text.isNotBlank()) onConfirm(text.trim()) }

    DoodlePanel(onDismiss, seed = 7) {
        Text(title.uppercase(), style = MaterialTheme.typography.labelMedium, color = accent)
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .doodleFrame(line = Chalk, ink = Chalk, radius = 16.dp, stroke = 1.6.dp, sketch = false, seed = 3)
                .padding(horizontal = 16.dp, vertical = 14.dp),
        ) {
            if (text.isEmpty()) {
                Text("Name", style = MaterialTheme.typography.bodyLarge, color = Fog)
            }
            BasicTextField(
                value = text,
                onValueChange = { if (it.length <= 40) text = it },
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyLarge.copy(color = Chalk),
                cursorBrush = SolidColor(accent),
                keyboardOptions = KeyboardOptions(
                    imeAction = ImeAction.Done,
                    capitalization = KeyboardCapitalization.Sentences,
                ),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
            )
        }
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            DoodleButton(onClick = onDismiss, modifier = Modifier.weight(1f), filled = false, seed = 5) {
                Text("CANCEL", style = MaterialTheme.typography.labelMedium, color = Chalk)
            }
            DoodleButton(onClick = { submit() }, modifier = Modifier.weight(1f), filled = true, seed = 8) {
                Text(confirmLabel.uppercase(), style = MaterialTheme.typography.labelMedium, color = ink)
            }
        }
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    val ink = LocalAccentInk.current
    DoodlePanel(onDismiss, seed = 10) {
        Text(title, style = MaterialTheme.typography.titleLarge, color = Chalk)
        Spacer(Modifier.height(8.dp))
        Text(message, style = MaterialTheme.typography.bodyLarge, color = Fog)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            DoodleButton(onClick = onDismiss, modifier = Modifier.weight(1f), filled = false, seed = 5) {
                Text("CANCEL", style = MaterialTheme.typography.labelMedium, color = Chalk)
            }
            DoodleButton(onClick = onConfirm, modifier = Modifier.weight(1f), filled = true, seed = 8) {
                Text(confirmLabel.uppercase(), style = MaterialTheme.typography.labelMedium, color = ink)
            }
        }
    }
}

@Composable
fun PlaylistPickerDialog(
    playlists: List<Playlist>,
    song: Song,
    onPick: (Playlist) -> Unit,
    onNew: () -> Unit,
    onDismiss: () -> Unit,
) {
    DoodlePanel(onDismiss, seed = 11) {
        Text("ADD TO PLAYLIST", style = MaterialTheme.typography.labelMedium, color = LocalAccent.current)
        Spacer(Modifier.height(10.dp))
        Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
            MenuItem(Glyph.Plus, "New playlist", onClick = onNew)
            playlists.forEach { playlist ->
                val has = song.id in playlist.songIds
                MenuItem(
                    glyph = if (has) Glyph.Check else Glyph.Lines,
                    label = "${playlist.name}  ·  ${playlist.songIds.size}",
                    onClick = { onPick(playlist) },
                )
            }
        }
    }
}

@Composable
private fun OptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    val accent = LocalAccent.current
    Row(
        Modifier
            .fillMaxWidth()
            .bouncyClickable(pressedScale = 0.97f, onClick = onClick)
            .padding(vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label,
            style = MaterialTheme.typography.titleMedium,
            color = if (selected) accent else Chalk,
            modifier = Modifier.weight(1f),
        )
        if (selected) DoodleIcon(Glyph.Check, tint = accent, size = 22.dp)
    }
}

@Composable
fun SortDialog(current: SortOrder, onPick: (SortOrder) -> Unit, onDismiss: () -> Unit) {
    DoodlePanel(onDismiss, seed = 13) {
        Text("SORT LIBRARY BY", style = MaterialTheme.typography.labelMedium, color = LocalAccent.current)
        Spacer(Modifier.height(8.dp))
        SortOrder.values().forEach { order ->
            OptionRow(order.label, order == current) { onPick(order) }
        }
    }
}

@Composable
fun SleepTimerDialog(endsAt: Long, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val active = endsAt > System.currentTimeMillis()
    DoodlePanel(onDismiss, seed = 15) {
        Text("SLEEP TIMER", style = MaterialTheme.typography.labelMedium, color = LocalAccent.current)
        if (active) {
            val minutes = ((endsAt - System.currentTimeMillis()) / 60_000L) + 1
            Spacer(Modifier.height(4.dp))
            Text("Music stops in about $minutes min", style = MaterialTheme.typography.bodyMedium, color = Fog)
        }
        Spacer(Modifier.height(8.dp))
        listOf(15, 30, 45, 60, 90).forEach { minutes ->
            OptionRow("$minutes minutes", false) { onPick(minutes) }
        }
        if (active) OptionRow("Turn off", false) { onPick(0) }
    }
}

@Composable
private fun MenuItem(
    glyph: Glyph,
    label: String,
    onClick: () -> Unit,
    filled: Boolean = false,
    tint: androidx.compose.ui.graphics.Color = Chalk,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .bouncyClickable(pressedScale = 0.97f, onClick = onClick)
            .padding(vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        DoodleIcon(glyph, tint = tint, size = 22.dp, filled = filled)
        Spacer(Modifier.width(16.dp))
        Text(
            label,
            style = MaterialTheme.typography.titleMedium,
            color = Chalk,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
fun TrackDetailsDialog(
    song: Song,
    loadDetails: suspend (Song) -> TrackDetails,
    onDismiss: () -> Unit,
) {
    val details = produceState(TrackDetails(song = song), song.id) { value = loadDetails(song) }.value
    val ink = LocalAccentInk.current
    val rows = buildList {
        add("TITLE" to song.title)
        add("ARTIST" to song.artist)
        add("ALBUM" to song.album.ifBlank { "Unknown album" })
        if (song.track > 0) add("TRACK NO." to song.track.toString())
        if (details.year > 0) add("YEAR" to details.year.toString())
        add("LENGTH" to formatDuration(song.durationMs))
        if (details.mimeType.isNotBlank()) add("FORMAT" to details.mimeType.substringAfter('/').uppercase())
        if (details.bitrateBps > 0) add("BITRATE" to "${details.bitrateBps / 1000} kbps")
        formatSize(details.sizeBytes).takeIf { it.isNotBlank() }?.let { add("SIZE" to it) }
        if (details.fileName.isNotBlank()) add("FILE" to details.fileName)
        if (details.folder.isNotBlank()) add("FOLDER" to details.folder)
        formatDate(details.addedSeconds).takeIf { it.isNotBlank() }?.let { add("ADDED" to it) }
    }
    DoodlePanel(onDismiss, seed = 9) {
        Text("TRACK DETAILS", style = MaterialTheme.typography.labelMedium, color = LocalAccent.current)
        Spacer(Modifier.height(14.dp))
        Column(
            Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            rows.forEach { (label, value) ->
                Column {
                    Text(label, style = MaterialTheme.typography.labelSmall, color = Fog)
                    Text(value, style = MaterialTheme.typography.bodyLarge, color = Chalk)
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        DoodleButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth(), filled = true, seed = 12) {
            Text("DONE", style = MaterialTheme.typography.labelMedium, color = ink)
        }
    }
}
