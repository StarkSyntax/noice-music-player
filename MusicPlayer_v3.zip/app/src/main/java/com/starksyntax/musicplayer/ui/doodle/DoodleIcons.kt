package com.starksyntax.musicplayer.ui.doodle

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/** Every icon in the app. Drawn by hand (well, by code) so they all share the same wobbly pen. */
enum class Glyph {
    Play, Pause, Next, Previous, Shuffle, Repeat, RepeatOne,
    Heart, More, Search, Close, Back, ChevronDown,
    Queue, Info, Album, Artist, Settings, Check, Note,
    Plus, Trash, Edit, Timer, Share, Sort, Lines,
}

/** One pen stroke on a 24 x 24 grid. */
private class GlyphPath(
    val pts: List<Offset>,
    val closed: Boolean = false,
    val filled: Boolean = false,
    val smooth: Boolean = false,
    val dot: Boolean = false,
)

private fun poly(
    vararg c: Float,
    closed: Boolean = false,
    filled: Boolean = false,
    smooth: Boolean = false,
): GlyphPath {
    val pts = ArrayList<Offset>()
    var i = 0
    while (i + 1 < c.size) {
        pts.add(Offset(c[i], c[i + 1]))
        i += 2
    }
    return GlyphPath(pts, closed = closed, filled = filled, smooth = smooth)
}

private fun circle(cx: Float, cy: Float, r: Float, filled: Boolean = false): GlyphPath {
    val n = 14
    val pts = (0 until n).map { k ->
        val a = 2.0 * PI * k / n
        Offset(cx + r * cos(a).toFloat(), cy + r * sin(a).toFloat())
    }
    return GlyphPath(pts, closed = true, filled = filled, smooth = true)
}

private fun dot(x: Float, y: Float) = GlyphPath(listOf(Offset(x, y)), dot = true)

private fun heart(filled: Boolean): GlyphPath {
    val n = 28
    val pts = (0 until n).map { k ->
        val t = 2.0 * PI * k / n
        val x = 16.0 * sin(t).pow(3)
        val y = 13.0 * cos(t) - 5.0 * cos(2 * t) - 2.0 * cos(3 * t) - cos(4 * t)
        Offset((12.0 + x * 0.64).toFloat(), (10.4 - y * 0.62).toFloat())
    }
    return GlyphPath(pts, closed = true, filled = filled, smooth = true)
}

private fun repeatLoop(): List<GlyphPath> = listOf(
    poly(5f, 12f, 5f, 9f, 7.5f, 6.5f, 18f, 6.5f),
    poly(15.5f, 3.8f, 18.2f, 6.5f, 15.5f, 9.2f),
    poly(19f, 12f, 19f, 15f, 16.5f, 17.5f, 6f, 17.5f),
    poly(8.5f, 14.8f, 5.8f, 17.5f, 8.5f, 20.2f),
)

private fun glyphsFor(glyph: Glyph, filled: Boolean): List<GlyphPath> = when (glyph) {
    Glyph.Play -> listOf(poly(8f, 5f, 19f, 12f, 8f, 19f, closed = true, filled = true))
    Glyph.Pause -> listOf(
        poly(6.5f, 5f, 10.5f, 5f, 10.5f, 19f, 6.5f, 19f, closed = true, filled = true),
        poly(13.5f, 5f, 17.5f, 5f, 17.5f, 19f, 13.5f, 19f, closed = true, filled = true),
    )
    Glyph.Next -> listOf(
        poly(6f, 5f, 15f, 12f, 6f, 19f, closed = true, filled = true),
        poly(18.5f, 5f, 18.5f, 19f),
    )
    Glyph.Previous -> listOf(
        poly(18f, 5f, 9f, 12f, 18f, 19f, closed = true, filled = true),
        poly(5.5f, 5f, 5.5f, 19f),
    )
    Glyph.Shuffle -> listOf(
        poly(3f, 7f, 8f, 7f, 16f, 17f, 19f, 17f),
        poly(16.5f, 14.5f, 19.5f, 17f, 16.5f, 19.5f),
        poly(3f, 17f, 8f, 17f, 10.5f, 14f),
        poly(13.5f, 10f, 16f, 7f, 19f, 7f),
        poly(16.5f, 4.5f, 19.5f, 7f, 16.5f, 9.5f),
    )
    Glyph.Repeat -> repeatLoop()
    Glyph.RepeatOne -> repeatLoop() + poly(11f, 10.8f, 12.6f, 9.6f, 12.6f, 14.6f)
    Glyph.Heart -> listOf(heart(filled))
    Glyph.More -> listOf(dot(12f, 5f), dot(12f, 12f), dot(12f, 19f))
    Glyph.Search -> listOf(circle(10.5f, 10.5f, 6f), poly(15f, 15f, 20f, 20f))
    Glyph.Close -> listOf(poly(6f, 6f, 18f, 18f), poly(18f, 6f, 6f, 18f))
    Glyph.Back -> listOf(poly(15f, 5f, 8f, 12f, 15f, 19f))
    Glyph.ChevronDown -> listOf(poly(5f, 9f, 12f, 16f, 19f, 9f))
    Glyph.Queue -> listOf(
        poly(4f, 7f, 14f, 7f),
        poly(4f, 12f, 14f, 12f),
        poly(4f, 17f, 10f, 17f),
        poly(17f, 12f, 17f, 18f),
        poly(14f, 15f, 20f, 15f),
    )
    Glyph.Info -> listOf(circle(12f, 12f, 9f), poly(12f, 11f, 12f, 17f), dot(12f, 7.6f))
    Glyph.Album -> listOf(circle(12f, 12f, 9f), circle(12f, 12f, 2.6f))
    Glyph.Artist -> listOf(
        circle(12f, 8f, 3.6f),
        poly(5f, 20f, 6f, 15.5f, 12f, 13.5f, 18f, 15.5f, 19f, 20f, smooth = true),
    )
    Glyph.Settings -> listOf(
        poly(4f, 6f, 20f, 6f),
        poly(4f, 12f, 20f, 12f),
        poly(4f, 18f, 20f, 18f),
        circle(8f, 6f, 2.3f, filled = true),
        circle(16f, 12f, 2.3f, filled = true),
        circle(10f, 18f, 2.3f, filled = true),
    )
    Glyph.Check -> listOf(poly(5f, 12.5f, 10f, 17.5f, 19f, 7f))
    Glyph.Plus -> listOf(poly(12f, 5f, 12f, 19f), poly(5f, 12f, 19f, 12f))
    Glyph.Trash -> listOf(
        poly(4.5f, 7f, 19.5f, 7f),
        poly(9f, 7f, 9f, 4.5f, 15f, 4.5f, 15f, 7f),
        poly(6.5f, 7f, 7.5f, 20f, 16.5f, 20f, 17.5f, 7f),
        poly(10.5f, 10.5f, 10.5f, 16.5f),
        poly(13.5f, 10.5f, 13.5f, 16.5f),
    )
    Glyph.Edit -> listOf(
        poly(5f, 19f, 5.8f, 14.6f, 15.5f, 4.9f, 19.1f, 8.5f, 9.4f, 18.2f, closed = true),
        poly(13.4f, 7f, 17f, 10.6f),
    )
    Glyph.Timer -> listOf(
        circle(12f, 13.5f, 7.5f),
        poly(12f, 13.5f, 12f, 9.5f),
        poly(9.5f, 3.8f, 14.5f, 3.8f),
    )
    Glyph.Share -> listOf(
        circle(6f, 12f, 2.4f, filled = true),
        circle(18f, 6f, 2.4f, filled = true),
        circle(18f, 18f, 2.4f, filled = true),
        poly(8f, 11f, 16f, 7f),
        poly(8f, 13f, 16f, 17f),
    )
    Glyph.Sort -> listOf(poly(4f, 7f, 20f, 7f), poly(4f, 12f, 15f, 12f), poly(4f, 17f, 10f, 17f))
    Glyph.Lines -> listOf(
        poly(9f, 7f, 20f, 7f), poly(9f, 12f, 20f, 12f), poly(9f, 17f, 20f, 17f),
        dot(4.5f, 7f), dot(4.5f, 12f), dot(4.5f, 17f),
    )
    Glyph.Note -> listOf(
        poly(9f, 17f, 9f, 5f, 19f, 3f, 19f, 15f),
        circle(6.8f, 17f, 2.6f, filled = true),
        circle(16.8f, 15f, 2.6f, filled = true),
    )
}

private fun DrawScope.drawGlyphPath(g: GlyphPath, color: Color, strokePx: Float, unit: Float, seed: Int) {
    val wobble = unit * 0.3f
    if (g.dot) {
        val c = g.pts[0]
        drawCircle(
            color = color,
            radius = strokePx * 0.62f,
            center = Offset(c.x * unit + noise(seed, 1) * wobble, c.y * unit + noise(seed, 2) * wobble),
        )
        return
    }
    val scaled = g.pts.map { Offset(it.x * unit, it.y * unit) }
    val path = if (g.smooth) {
        smoothPath(jitter(scaled, wobble, seed), g.closed)
    } else {
        linePath(jitter(subdivide(scaled, unit * 6f, g.closed), wobble, seed), g.closed)
    }
    if (g.filled) drawPath(path, color)
    drawPath(path, color, style = Stroke(width = strokePx, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

/**
 * A hand-drawn icon. Pass [Dp.Unspecified] as [size] to size it through [modifier] instead.
 * [filled] only matters for glyphs that have a solid variant (the heart).
 */
@Composable
fun DoodleIcon(
    glyph: Glyph,
    tint: Color,
    modifier: Modifier = Modifier,
    size: Dp = 24.dp,
    filled: Boolean = false,
    weight: Float = 1.9f,
    seed: Int = glyph.ordinal + 1,
) {
    val paths = remember(glyph, filled) { glyphsFor(glyph, filled) }
    val base = if (size == Dp.Unspecified) modifier else modifier.size(size)
    Canvas(base) {
        val unit = this.size.width / 24f
        paths.forEachIndexed { i, path ->
            drawGlyphPath(path, tint, unit * weight, unit, seed + i * 31)
        }
    }
}
