package com.starksyntax.musicplayer.ui.doodle

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.starksyntax.musicplayer.ui.theme.Chalk
import com.starksyntax.musicplayer.ui.theme.Fog
import com.starksyntax.musicplayer.ui.theme.Ink
import com.starksyntax.musicplayer.ui.theme.LocalAccent
import com.starksyntax.musicplayer.ui.theme.LocalAccentInk
import kotlin.math.max

/** Click handler with a little squash-and-bounce instead of a ripple. */
@Composable
fun Modifier.bouncyClickable(
    enabled: Boolean = true,
    pressedScale: Float = 0.9f,
    onClick: () -> Unit,
): Modifier {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium,
        ),
        label = "press",
    )
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = interaction,
            indication = null,
            enabled = enabled,
            onClick = onClick,
        )
}

/** Full-screen black layer that swallows touches so nothing underneath reacts. */
@Composable
fun Modifier.opaqueOverlay(): Modifier = this
    .fillMaxSize()
    .background(Ink)
    .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = {},
    )

@Composable
fun DoodleIconButton(
    glyph: Glyph,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = Chalk,
    iconSize: Dp = 24.dp,
    filled: Boolean = false,
    hitSize: Dp = 48.dp,
) {
    Box(
        modifier
            .size(hitSize)
            .bouncyClickable(onClick = onClick)
            .semantics {
                contentDescription = description
                role = Role.Button
            },
        contentAlignment = Alignment.Center,
    ) {
        DoodleIcon(glyph = glyph, tint = tint, size = iconSize, filled = filled)
    }
}

/** Pill button: accent-filled with pen hatching, or a plain white outline. */
@Composable
fun DoodleButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = true,
    seed: Int = 3,
    content: @Composable RowScope.() -> Unit,
) {
    val accent = LocalAccent.current
    val accentInk = LocalAccentInk.current
    Row(
        modifier
            .bouncyClickable(onClick = onClick)
            .doodleFrame(
                line = if (filled) accent else Chalk,
                fill = if (filled) accent else null,
                ink = if (filled) accentInk else Chalk,
                radius = 22.dp,
                stroke = 2.dp,
                hatch = filled,
                seed = seed,
            )
            .padding(horizontal = 18.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

/** Big round button (the play button). */
@Composable
fun DoodleCircleButton(
    glyph: Glyph,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 76.dp,
    fill: Color = LocalAccent.current,
    ink: Color = LocalAccentInk.current,
    seed: Int = 7,
) {
    Box(
        modifier
            .size(size)
            .bouncyClickable(onClick = onClick)
            .semantics {
                contentDescription = description
                role = Role.Button
            }
            .doodleFrame(
                line = fill,
                fill = fill,
                ink = ink,
                radius = size,
                stroke = 2.4.dp,
                hatch = true,
                seed = seed,
            ),
        contentAlignment = Alignment.Center,
    ) {
        DoodleIcon(glyph = glyph, tint = ink, size = size * 0.46f)
    }
}

/**
 * Hand-drawn slider used for the seek bar and the hue picker.
 *
 * [onChange] fires while dragging (and on tap), [onChangeFinished] when the finger lifts.
 * Pass [trackColors] to paint a gradient track (hue picker) instead of an active/inactive pair.
 */
@Composable
fun DoodleSlider(
    fraction: Float,
    onChange: (Float) -> Unit,
    onChangeFinished: (Float) -> Unit,
    modifier: Modifier = Modifier,
    activeColor: Color = LocalAccent.current,
    inactiveColor: Color = Color(0x40FFFFFF),
    trackColors: List<Color>? = null,
    knobColor: Color = LocalAccent.current,
    knobInk: Color = LocalAccentInk.current,
    seed: Int = 21,
) {
    val currentOnChange by rememberUpdatedState(onChange)
    val currentOnFinished by rememberUpdatedState(onChangeFinished)
    var dragging by remember { mutableStateOf(false) }
    val knobScale by animateFloatAsState(
        targetValue = if (dragging) 1.35f else 1f,
        label = "knobScale",
    )
    val inset = 14.dp

    Canvas(
        modifier
            .fillMaxWidth()
            .height(44.dp)
            .pointerInput(Unit) {
                val insetPx = inset.toPx()
                detectTapGestures { offset ->
                    val f = ((offset.x - insetPx) / (size.width - 2 * insetPx)).coerceIn(0f, 1f)
                    currentOnChange(f)
                    currentOnFinished(f)
                }
            }
            .pointerInput(Unit) {
                val insetPx = inset.toPx()
                var last = 0f
                fun fractionAt(x: Float): Float =
                    ((x - insetPx) / (size.width - 2 * insetPx)).coerceIn(0f, 1f)
                detectHorizontalDragGestures(
                    onDragStart = { offset ->
                        dragging = true
                        last = fractionAt(offset.x)
                        currentOnChange(last)
                    },
                    onDragEnd = {
                        dragging = false
                        currentOnFinished(last)
                    },
                    onDragCancel = { dragging = false },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        last = fractionAt(change.position.x)
                        currentOnChange(last)
                    },
                )
            },
    ) {
        val insetPx = inset.toPx()
        val cy = size.height / 2f
        val trackPx = 5.dp.toPx()
        val startX = insetPx
        val endX = size.width - insetPx
        val progressX = startX + (endX - startX) * fraction.coerceIn(0f, 1f)

        // Wobbly track: same noise every frame, so it never shimmers.
        val n = max(2, ((endX - startX) / 22.dp.toPx()).toInt())
        val points = (0..n).map { i ->
            Offset(startX + (endX - startX) * i / n, cy + noise(seed, i) * 1.6.dp.toPx())
        }
        val trackStyle = Stroke(width = trackPx, cap = StrokeCap.Round, join = StrokeJoin.Round)
        val track = smoothPath(points, closed = false)

        if (trackColors != null) {
            drawPath(
                track,
                Brush.horizontalGradient(colors = trackColors, startX = startX, endX = endX),
                style = trackStyle,
            )
        } else {
            drawPath(track, inactiveColor, style = trackStyle)
            val active = points.takeWhile { it.x <= progressX } + Offset(progressX, cy)
            if (active.size >= 2) {
                drawPath(smoothPath(active, closed = false), activeColor, style = trackStyle)
            }
        }

        // Knob: a doodled circle with a pen ring and a centre dot.
        val r = 10.dp.toPx() * knobScale
        drawCircle(color = knobColor, radius = r, center = Offset(progressX, cy))
        drawPath(
            doodleCirclePath(progressX, cy, r * 0.72f, 1.0.dp.toPx(), seed + 3),
            knobInk.copy(alpha = 0.75f),
            style = Stroke(width = 1.4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
        drawCircle(color = knobInk.copy(alpha = 0.8f), radius = r * 0.22f, center = Offset(progressX, cy))
    }
}

/** Four-ish equal tabs with a hand-drawn squiggle under the selected one. */
@Composable
fun DoodleTabs(
    labels: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val accent = LocalAccent.current
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 6.dp),
    ) {
        labels.forEachIndexed { i, label ->
            val selected = i == selectedIndex
            Box(
                Modifier
                    .weight(1f)
                    .height(46.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier
                        .then(if (selected) Modifier.doodleUnderline(accent, seed = i + 3) else Modifier)
                        .padding(horizontal = 2.dp, vertical = 8.dp),
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 0.4.sp),
                        color = if (selected) accent else Fog,
                        maxLines = 1,
                        softWrap = false,
                    )
                }
            }
        }
    }
}

/** Three marker-drawn bars that bounce while music plays. Size it through [modifier]. */
@Composable
fun EqualizerBars(
    playing: Boolean,
    color: Color,
    modifier: Modifier = Modifier,
) {
    val transition = rememberInfiniteTransition(label = "equalizer")
    val durations = listOf(520, 380, 640)
    val heights = durations.mapIndexed { index, duration ->
        transition.animateFloat(
            initialValue = 0.25f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = duration, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse,
            ),
            label = "bar$index",
        )
    }

    Canvas(modifier) {
        val barWidth = size.width / 5f
        val baseline = size.height - barWidth / 2f
        val travel = size.height - barWidth
        heights.forEachIndexed { index, height ->
            val fraction = if (playing) height.value else 0.3f
            val x = barWidth * (index * 2 + 0.5f)
            drawLine(
                color = color,
                start = Offset(x, baseline),
                end = Offset(x, baseline - travel * fraction),
                strokeWidth = barWidth,
                cap = StrokeCap.Round,
            )
        }
    }
}

/** Small hand-drawn message bubble. */
@Composable
fun DoodleToast(message: String, modifier: Modifier = Modifier) {
    Box(
        modifier
            .doodleFrame(line = Chalk, fill = Ink, ink = Chalk, radius = 20.dp, stroke = 2.dp, seed = 9)
            .padding(horizontal = 24.dp, vertical = 16.dp),
    ) {
        Text(
            text = message,
            style = MaterialTheme.typography.titleMedium,
            color = Chalk,
        )
    }
}
